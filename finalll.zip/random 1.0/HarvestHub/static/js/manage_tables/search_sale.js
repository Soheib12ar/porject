console.log("search_sale.js loaded");

const searchField = document.querySelector('#searchField');

const tableOutput = document.querySelector('.table-output');
tableOutput.style.display = 'none';

const appTable = document.querySelector('.app-table');
const paginationContainer = document.querySelector('.pagination-container');

const tbody = document.querySelector('.table-body');

const noResultsDiv = document.querySelector('.no-results');
noResultsDiv.style.display = 'none';




searchField.addEventListener('keyup', (e) => {

    const searchValue = e.target.value;

    if (searchValue.trim().length > 0) {

        paginationContainer.style.display = 'none';
        

        
        fetch('/manage_tables/search_sale/', {
            body: JSON.stringify({ searchText: searchValue }),
            method: 'POST',
        })
            .then((res) => res.json())
            .then((data) => {


                tbody.innerHTML = "";


                appTable.style.display = 'none';

                tableOutput.style.display = 'block';
                
                if (data.length === 0) {
                    noResultsDiv.style.display = 'block';
                    tableOutput.style.display = 'none';
                }
                else {
                    noResultsDiv.style.display = 'none';
                    

                    data.forEach(item => {


                        tbody.innerHTML += `
                        <tr>
                            <td>${item.sale_id}</td>
                            <td>${item.sale_name}</td>
                            <td>${item.sale_price}</td>
                            <td>${item.sale_quantity}</td>
                            <td>${item.sale_category}</td>
                            <td>
                                <a href="/manage_tables/edit_sale/${item.sale_id}" class="btn btn-secondary">Edit</a>
                                <a href="/manage_tables/delete_sale/${item.sale_id}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>


                        
                        `
                    });

                    

                }
           
            });

    }
    else {
        appTable.style.display = 'block';
        paginationContainer.style.display = 'block';
        tableOutput.style.display = 'none';
        noResultsDiv.style.display = 'none';
    }

});







