console.log("charts.js loaded");

let purchaseData = {}

let chartInstance = null;
let productSaleChartInstance = null;
let monthlySalesChartInstance = null;
let monthlySalesChartInstance2 = null;
let monthlyIncomeChartInstance = null;

const purchasesTitle = document.getElementById("purchases-title");
const purchasesTotal = document.getElementById("purchases-total");


// Get data from backend

let currentYearButton = document.querySelector('.selected_year')

yearbutton(currentYearButton.id)
getCenterData(0)

function yearbutton(year) {

    currentYearButton.classList.remove('selected_year')
    currentYearButton.classList.remove('btn-primary')
    currentYearButton.classList.add('btn-secondary')

    currentYearButton = document.getElementById(year)
    currentYearButton.classList.remove('btn-secondary')
    currentYearButton.classList.add('btn-primary')
    currentYearButton.classList.add('selected_year')

    purchasesTitle.innerHTML = `Material purchases in ${year}`

    url = '/analysis/get_purchases_per_month/' + year

    getData(url)
}

function getData(url) {

    fetch(url)
        .then(response => response.json())
        .then(data => {

            console.log(data)
            purchaseData = data

            if (chartInstance) {
                chartInstance.destroy();
            }

            total = 0
            for (const [key, value] of Object.entries(data)) {
                total += value
            }

            purchasesTotal.innerHTML = `Total purchases made this year: ${total}`


            createPurchaseChart(purchaseData)

        })
}

// Chart.js

var product_purchase_chart = document.getElementById('product_purchase_chart');
var product_sale_chart = document.getElementById('product_sale_chart');
var client_sale_chart = document.getElementById('clients_chart');

function createPurchaseChart(data) {




    let labels = []
    let values = []

    for (const [key, value] of Object.entries(data)) {

        labels.push(key)
        values.push(value)
    }


    const myChart = new Chart(product_purchase_chart, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Purchases this month',
                data: values,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(99, 255, 132, 0.2)',
                    'rgba(132, 99, 255, 0.2)',
                    'rgba(132, 255, 99, 0.2)',
                    'rgba(255, 132, 99, 0.2)',
                    'rgba(255, 132, 255, 0.2)',
                    'rgba(255, 255, 132, 0.2)',
                    'rgba(132, 255, 255, 0.2)',
                    'rgba(255, 132, 132, 0.2)',
                    'rgba(132, 132, 255, 0.2)',
                    'rgba(132, 255, 132, 0.2)',
                    'rgba(255, 255, 255, 0.2)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(99, 255, 132, 1)',
                    'rgba(132, 99, 255, 1)',
                    'rgba(132, 255, 99, 1)',
                    'rgba(255, 132, 99, 1)',
                    'rgba(255, 132, 255, 1)',
                    'rgba(255, 255, 132, 1)',
                    'rgba(132, 255, 255, 1)',
                    'rgba(255, 132, 132, 1)',
                    'rgba(132, 132, 255, 1)',
                    'rgba(132, 255, 132, 1)',
                    'rgba(255, 255, 255, 1)',
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });

    chartInstance = myChart;

    myChart.canvas.parentNode.style.height = '500px';
    myChart.canvas.parentNode.style.width = '800px';


    

}








// stats for sales

let salesData = {}

let currentCenterButton = document.querySelector('.selected_center')


function showstats(center) {



    currentCenterButton.classList.remove('selected_center')
    currentCenterButton.classList.remove('btn-primary')
    currentCenterButton.classList.add('btn-secondary')

    currentCenterButton = document.getElementById(center)
    currentCenterButton.classList.remove('btn-secondary')
    currentCenterButton.classList.add('btn-primary')





    getCenterData(center)

}


function getCenterData(center) {
    

    


    url = '/analysis/get_center_sales_stats/' + center

    fetch(url)
        .then(response => response.json())
        .then(data => {
            salesData = data


            /*
            data = {
            'sales_count':sales_count,
            'sales_amount':sales_amount,
            'product_sales':product_sales,
            'client_sales':client_sales,
            }*/

            if (productSaleChartInstance) {
                productSaleChartInstance.destroy();
            }
            createSalesChart(salesData)

            if (clientSaleChartInstance) {
                clientSaleChartInstance.destroy();
            }
            createClientChart(salesData)

            if (monthlySalesChartInstance) {
                monthlySalesChartInstance.destroy();
            }
            createMonthlySalesChart(salesData)

               

        })
}

function createSalesChart(data) {

    let labels = []
    let values = []

   // example data for product sales : {'product1': 1, 'product2': 2, 'product3': 3} 

    for (const [key, value] of Object.entries(data['product_sales'])) {

        labels.push(value[0])
        
        values.push(value[1])
    }

    const productSaleChart = new Chart(product_sale_chart, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                label: 'Quantity sold',
                data: values,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(99, 255, 132, 0.2)',
                    'rgba(132, 99, 255, 0.2)',
                    'rgba(132, 255, 99, 0.2)',
                    'rgba(255, 132, 99, 0.2)',
                    'rgba(255, 132, 255, 0.2)',
                    'rgba(255, 255, 132, 0.2)',
                    'rgba(132, 255, 255, 0.2)',
                    'rgba(255, 132, 132, 0.2)',
                    'rgba(132, 132, 255, 0.2)',
                    'rgba(132, 255, 132, 0.2)',
                    'rgba(255, 255, 255, 0.2)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(99, 255, 132, 1)',
                    'rgba(132, 99, 255, 1)',
                    'rgba(132, 255, 99, 1)',
                    'rgba(255, 132, 99, 1)',
                    'rgba(255, 132, 255, 1)',
                    'rgba(255, 255, 132, 1)',
                    'rgba(132, 255, 255, 1)',
                    'rgba(255, 132, 132, 1)',
                    'rgba(132, 132, 255, 1)',
                    'rgba(132, 255, 132, 1)',
                    'rgba(255, 255, 255, 1)',
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });

    productSaleChartInstance = productSaleChart;

    productSaleChart.canvas.parentNode.style.height = '600px';
    productSaleChart.canvas.parentNode.style.width = '500px';

}



// stats for clients

let clientSaleChartInstance = null;

function createClientChart(data) {

    let labels = []
    let values = []

   

    const sortedClients = Object.entries(data['client_sales'])
        .sort((a, b) => b[1][1] - a[1][1])
        .slice(0, 5);

    for (const [key, value] of sortedClients) {
        labels.push(value[0]);
        values.push(value[1]);
    }

    

    const clientSaleChart = new Chart(client_sale_chart, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Sales made',
                data: values,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(99, 255, 132, 0.2)',
                    'rgba(132, 99, 255, 0.2)',
                    'rgba(132, 255, 99, 0.2)',
                    'rgba(255, 132, 99, 0.2)',
                    'rgba(255, 132, 255, 0.2)',
                    'rgba(255, 255, 132, 0.2)',
                    'rgba(132, 255, 255, 0.2)',
                    'rgba(255, 132, 132, 0.2)',
                    'rgba(132, 132, 255, 0.2)',
                    'rgba(132, 255, 132, 0.2)',
                    'rgba(255, 255, 255, 0.2)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(99, 255, 132, 1)',
                    'rgba(132, 99, 255, 1)',
                    'rgba(132, 255, 99, 1)',
                    'rgba(255, 132, 99, 1)',
                    'rgba(255, 132, 255, 1)',
                    'rgba(255, 255, 132, 1)',
                    'rgba(132, 255, 255, 1)',
                    'rgba(255, 132, 132, 1)',
                    'rgba(132, 132, 255, 1)',
                    'rgba(132, 255, 132, 1)',
                    'rgba(255, 255, 255, 1)',
                ],

                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });

    clientSaleChartInstance = clientSaleChart;

    
    clientSaleChart.canvas.parentNode.style.height = '400px';
    clientSaleChart.canvas.parentNode.style.width = '600px';
}





























// sales per year

var monthly_sales_chart = document.getElementById('monthly_sales_chart');
var currentYearButtonSale = document.querySelector('.selected_year_sales')
var salesTitle = document.getElementById("sales-title");
var salesIncomeTital = document.getElementById("sales-income-title");



yearbuttonsale(2024)


function yearbuttonsale(year) {

    currentYearButtonSale.classList.remove('selected_year_sales')
    currentYearButtonSale.classList.remove('btn-primary')
    currentYearButtonSale.classList.add('btn-secondary')

    sale_year = year.toString()+ 'sales'
    currentYearButtonSale = document.getElementById(sale_year)
    currentYearButtonSale.classList.remove('btn-secondary')
    currentYearButtonSale.classList.add('btn-primary')
    currentYearButtonSale.classList.add('selected_year_sales')

    salesTitle.innerHTML = `Sales made in ${year}`
    salesIncomeTital.innerHTML = `Income made in ${year}`

    url = '/analysis/get_year_sales_stats/' + year

    getYearSalesData(url)
    

}

function getYearSalesData(url) {

    fetch(url)
        .then(response => response.json())
        .then(data => {
            salesData = data

            if (monthlySalesChartInstance2) {
                monthlySalesChartInstance2.destroy();
            }
            createMonthlySalesChart(salesData['sales_per_month'])


            if (monthlyIncomeChartInstance) {
                monthlyIncomeChartInstance.destroy();
            }
            createMonthlyIncomeChart(salesData['income_per_month'])

            console.log(salesData)

        })
}




function createMonthlySalesChart(data) {

    let labels = []
    let values = []

    for (const [key, value] of Object.entries(data)) {
            
            labels.push(key)
            values.push(value)
        }

    const monthlySalesChart = new Chart(monthly_sales_chart, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Sales made',
                data: values,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(99, 255, 132, 0.2)',
                    'rgba(132, 99, 255, 0.2)',
                    'rgba(132, 255, 99, 0.2)',
                    'rgba(255, 132, 99, 0.2)',
                    'rgba(255, 132, 255, 0.2)',
                    'rgba(255, 255, 132, 0.2)',
                    'rgba(132, 255, 255, 0.2)',
                    'rgba(255, 132, 132, 0.2)',
                    'rgba(132, 132, 255, 0.2)',
                    'rgba(132, 255, 132, 0.2)',
                    'rgba(255, 255, 255, 0.2)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(99, 255, 132, 1)',
                    'rgba(132, 99, 255, 1)',
                    'rgba(132, 255, 99, 1)',
                    'rgba(255, 132, 99, 1)',
                    'rgba(255, 132, 255, 1)',
                    'rgba(255, 255, 132, 1)',
                    'rgba(132, 255, 255, 1)',
                    'rgba(255, 132, 132, 1)',
                    'rgba(132, 132, 255, 1)',
                    'rgba(132, 255, 132, 1)',
                    'rgba(255, 255, 255, 1)',
                ],

                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });

    monthlySalesChartInstance2 = monthlySalesChart;

    monthlySalesChart.canvas.parentNode.style.height = '500px';
    monthlySalesChart.canvas.parentNode.style.width = '800px';
}





// income per year

var monthly_income_chart = document.getElementById('monthly_income_chart');

function createMonthlyIncomeChart(data) {

    let labels = []
    let values = []

    for (const [key, value] of Object.entries(data)) {
            
            labels.push(key)
            values.push(value)
        }

    const monthlyIncomeChart = new Chart(monthly_income_chart, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Income',
                data: values,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(99, 255, 132, 0.2)',
                    'rgba(132, 99, 255, 0.2)',
                    'rgba(132, 255, 99, 0.2)',
                    'rgba(255, 132, 99, 0.2)',
                    'rgba(255, 132, 255, 0.2)',
                    'rgba(255, 255, 132, 0.2)',
                    'rgba(132, 255, 255, 0.2)',
                    'rgba(255, 132, 132, 0.2)',
                    'rgba(132, 132, 255, 0.2)',
                    'rgba(132, 255, 132, 0.2)',
                    'rgba(255, 255, 255, 0.2)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(99, 255, 132, 1)',
                    'rgba(132, 99, 255, 1)',
                    'rgba(132, 255, 99, 1)',
                    'rgba(255, 132, 99, 1)',
                    'rgba(255, 132, 255, 1)',
                    'rgba(255, 255, 132, 1)',
                    'rgba(132, 255, 255, 1)',
                    'rgba(255, 132, 132, 1)',
                    'rgba(132, 132, 255, 1)',
                    'rgba(132, 255, 132, 1)',
                    'rgba(255, 255, 255, 1)',
                ],

                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
    
    monthlyIncomeChart.canvas.parentNode.style.height = '500px';
    monthlyIncomeChart.canvas.parentNode.style.width = '800px';

    monthlyIncomeChartInstance = monthlyIncomeChart;


}

