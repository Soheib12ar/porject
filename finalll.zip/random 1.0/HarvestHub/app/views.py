from django.shortcuts import render
from django.http import HttpResponse

from .models import material , supplier , mat_supp , material_purchase , center , material_transfer , material_sale , product
from django.core.paginator import Paginator
from django.contrib import messages
import json
from django.http import JsonResponse
import datetime

def index(request):
    return render(request, 'main/index.html')




def stock(request):


    if request.method == 'GET':
        return render(request, 'main/stock/stock.html')



def materials(request):

    materials = material.objects.all()
    materials = materials.order_by('material_id')

    pages = Paginator(materials, 10)
    page_number = request.GET.get('page')

    materials_obj = pages.get_page(page_number)

    context = {
        'materials': materials,
        'materials_obj': materials_obj
    }

    if request.method == 'GET':

        
        return render(request, 'main/stock/materials/materials.html', context)
    
def edit_materials(request, id):

    material_instance = material.objects.get(material_id=id)

    context = {
        'data': material_instance
    }

    if request.method == 'GET':
        return render(request, 'main/stock/materials/edit_materials.html' , context)
    
    if request.method == 'POST':

        material_name = request.POST.get('name')
        if not material_name:
            messages.error(request, "Material name cannot be empty")
            return render(request, 'main/stock/materials/edit_materials.html' , context)
        
        material_quantity = request.POST.get('quantity')
        if not material_quantity:
            messages.error(request, "Material quantity cannot be empty")
            return render(request, 'main/stock/materials/edit_materials.html' , context)
        
        material_description = request.POST.get('description')
        if not material_description:
            messages.error(request, "Material description cannot be empty")
            return render(request, 'main/stock/materials/edit_materials.html' , context)
        
        material.objects.filter(material_id=id).update(material_name=material_name, material_quantity=material_quantity, material_description=material_description)

        messages.success(request, "Material updated successfully")

        materials = material.objects.all()
        materials = materials.order_by('material_id')

        pages = Paginator(materials, 10)
        page_number = request.GET.get('page')

        materials_obj = pages.get_page(page_number)

        context = {
            'materials': materials,
            'materials_obj': materials_obj
        }
        
        return render(request, 'main/stock/materials/materials.html', context)

    

def delete_materials(request,id):

    if request.method == 'GET':
        
        material.objects.filter(material_id=id).delete()

        materials = material.objects.all()
        materials = materials.order_by('material_id')

        pages = Paginator(materials, 10)
        page_number = request.GET.get('page')

        materials_obj = pages.get_page(page_number)

        context = {
            'materials': materials,
            'materials_obj': materials_obj
        }

        return render(request, 'main/stock/materials/materials.html', context)
    

def search_material(request):

    
    if request.method == 'POST':

        search_str = json.loads(request.body).get('searchText')

        print(search_str)

        print("-------------------")

        materials = material.objects.filter(material_name__icontains=search_str)  | material.objects.filter(material_quantity__icontains=search_str) | material.objects.filter(material_description__icontains=search_str)

        data = materials.values()

        print(data)

        return JsonResponse(list(data), safe=False)
    
    


    
    



def buy_materials(request):

    suppliers = supplier.objects.all()
    materials = material.objects.all()

    context = {
        'suppliers': suppliers,
        'materials': materials
    }

    if request.method == 'GET':
        return render(request, 'main/stock/materials/buy_materials.html' , context)
    
    if request.method == 'POST':

        data = request.POST

        print('-------------------')
        print(data)
        print('-------------------')
       
        Supplier = request.POST.get('supplier')
        if not Supplier:
            messages.error(request, "Supplier cannot be empty")
            return render(request, 'main/stock/materials/buy_materials.html' , context)


        Material = request.POST.get('material')
        if not material:
            messages.error(request, "Material cannot be empty")
            return render(request, 'main/stock/materials/buy_materials.html' , context)
        

        quantity = request.POST.get('quantity')
        if not quantity:
            messages.error(request, "Quantity cannot be empty")
            return render(request, 'main/stock/materials/buy_materials.html' , context)
        

        date = datetime.date.today()

        payment = request.POST.get('payment')
        if payment == 'full':
            #amount = quantity * price from mat_supp table where material_id = material and supplier_id = supplier
            
            amount = price.mat_supp_price * int(quantity)

        else :
            amount = request.POST.get('amount')
            if not amount:
                messages.error(request, "Amount cannot be empty if payment is partial")
                return render(request, 'main/stock/materials/buy_materials.html' , context)
            

        price = mat_supp.objects.get(material_id=Material , supplier_id=Supplier).mat_supp_price

        #update material quantity
        material_instance = material.objects.get(material_id=Material)
        material_instance.material_quantity = material_instance.material_quantity + int(quantity)
        material_instance.save()

        #update supplier balance
        
        supplier_instance = supplier.objects.get(supplier_id=Supplier)
        if payment == 'partial':
            supplier_instance.supplier_balance = supplier_instance.supplier_balance+ int(price) - int(amount) 
            supplier_instance.save()

        #add to material_purchase table
        material_purchase.objects.create(material_purchase_material=material_instance , material_purchase_supplier=supplier_instance , material_purchase_quantity=quantity , material_purchase_date=date)

        messages.success(request, "Material purchased successfully")

        #go to purchases list
        purchases = material_purchase.objects.all()
        purchases = purchases.order_by('material_purchase_id')

        pages = Paginator(purchases, 10)
        page_number = request.GET.get('page')

        purchases_obj = pages.get_page(page_number)


        context = {
                'data' : data,
                'purchases': purchases,
                'purchases_obj': purchases_obj,
                'suppliers': suppliers,
            }
        
        return render(request, 'main/stock/purchases/purchases_list.html' , context)
            


    

def get_suppliers(request , id):
    

    if request.method == 'POST':  

        mat_supps = mat_supp.objects.filter(material_id=id)

        data = []

        for m in mat_supps:
            # get id name 
            data.append({'id': m.supplier_id.supplier_id, 'name': m.supplier_id.supplier_name })

        print(data)

        print('-------------------')

        return JsonResponse(data, safe=False)

def get_materials(request, id):

    if request.method == 'POST':


        materials = mat_supp.objects.filter(supplier_id=id)
        mat = material.objects.all()

        data = []

        for x in mat :
            for y in materials:
                if x.material_id == y.material_id.material_id:
                    data.append({'id': x.material_id, 'name': x.material_name , 'price': y.mat_supp_price })
    
        
        print(data)
        return JsonResponse(data, safe=False)



    
    

def sell_materials(request):

    materials = material.objects.all()

    context = {
        'materials': materials
    }

    if request.method == 'GET':
        return render(request, 'main/stock/materials/sell_materials.html' , context)
    
    if request.method == 'POST':

        data = request.POST

        print('-------------------')
        print(data)
        print('-------------------')

        Material = request.POST.get('material')
        if not Material:
            messages.error(request, "Material cannot be empty")
            return render(request, 'main/stock/materials/sell_materials.html' , context)
        

        quantity = request.POST.get('quantity')
        if not quantity:
            messages.error(request, "Quantity cannot be empty")
            return render(request, 'main/stock/materials/sell_materials.html' , context)
        elif int(quantity) < 0:
            messages.error(request, "Quantity cannot be negative")
            return render(request, 'main/stock/materials/sell_materials.html' , context)
        elif int(quantity) == 0:
            messages.error(request, "Quantity cannot be zero")
            return render(request, 'main/stock/materials/sell_materials.html' , context)
        elif int(quantity) > material.objects.get(material_id=Material).material_quantity:
            messages.error(request, f"Quantity cannot be greater than available quantity ({material.objects.get(material_id=Material).material_quantity}) ")
            return render(request, 'main/stock/materials/sell_materials.html' , context)
        


        #update material quantity
        material_instance = material.objects.get(material_id=Material)
        material_instance.material_quantity = material_instance.material_quantity - int(quantity)
        material_instance.save()

        #add to sells table (material_sell)
        #material_sell.objects.create(material_sell_material=material_instance , material_sell_quantity=quantity)

        messages.success(request, "Material sold successfully")
        """
        #go to sells list
        sells = material_sell.objects.all()
        sells = sells.order_by('material_sell_id')

        
        pages = Paginator(sells, 10)
        page_number = request.GET.get('page')
        sells_obj = pages.get_page(page_number)
        context = {
                'data' : data,
                'sells': sells,
                'sells_obj': sells_obj,
                'materials': materials,
            }
        return render(request, 'main/stock/materials/sells_list.html' , context)
        """

        #reload the page
        return render(request, 'main/stock/materials/sell_materials.html' , context)

    

def purchases_list(request):

    purchases = material_purchase.objects.all()
    purchases = purchases.order_by('material_purchase_id')

    pages = Paginator(purchases, 10)
    page_number = request.GET.get('page')

    purchases_obj = pages.get_page(page_number)

    context = {

        'purchases': purchases,
        'purchases_obj': purchases_obj
    }

    if request.method == 'GET':
        return render(request, 'main/stock/purchases/purchases_list.html' , context)
    
    if request.method == 'POST':
            
            return render(request, 'main/stock/materials/purchases_list.html' , context)
    



    

def transfers_list(request , id=None):

    if id:
        transfers = material_transfer.objects.filter(material_transfer_center=id)
    else:
        transfers = material_transfer.objects.all()


    transfers = transfers.order_by('material_transfer_id')
    pages = Paginator(transfers, 10)
    page_number = request.GET.get('page')
    transfers_obj = pages.get_page(page_number)


    

    context = {
            
            'transfers': transfers,
            'transfers_obj': transfers_obj
        }
    
    if request.method == 'GET':
        return render(request, 'main/stock/transfers/transfers_list.html' , context)
    
    
    





def add_transfer(request):

    materials = material.objects.all()
    centers = center.objects.all()

    context = {
        'materials': materials,
        'centers': centers
    }

    if request.method == 'GET':
        
        return render(request, 'main/stock/transfers/add_transfer.html' , context)
    
    if request.method == 'POST':
        
        transfer_material = request.POST.get('material')

        if not transfer_material:
            messages.error(request, "Material cannot be empty")
            return render(request, 'main/stock/transfers/add_transfer.html' , context)
        

        transfer_center = request.POST.get('center')
        if not transfer_center:
            messages.error(request, "Center cannot be empty")
            return render(request, 'main/stock/transfers/add_transfer.html' , context)
        

        transfer_quantity = request.POST.get('quantity')
        if not transfer_quantity:
            messages.error(request, "Quantity cannot be empty")
            return render(request, 'main/stock/transfers/add_transfer.html' , context)
        elif int(transfer_quantity) < 0:
            messages.error(request, "Quantity cannot be negative")
            return render(request, 'main/stock/transfers/add_transfer.html' , context)
        elif int(transfer_quantity) == 0:
            messages.error(request, "Quantity cannot be zero")
            return render(request, 'main/stock/transfers/add_transfer.html' , context)
        elif int(transfer_quantity) > material.objects.get(material_id=transfer_material).material_quantity:
            messages.error(request, f"Quantity cannot be greater than available quantity ({material.objects.get(material_id=transfer_material).material_quantity}) ")
            return render(request, 'main/stock/transfers/add_transfer.html' , context)
        

        date = datetime.date.today()
        

        #update material quantity
        material_instance = material.objects.get(material_id=transfer_material)
        material_instance.material_quantity = material_instance.material_quantity - int(transfer_quantity)
        material_instance.save()

       
        #add to material_transfer table
        material_transfer.objects.create(material_transfer_material=material_instance , material_transfer_center=center.objects.get(center_id=transfer_center) , material_transfer_quantity=transfer_quantity , material_transfer_date=date)
        
        messages.success(request, "Material transferred successfully")

        #go to transfers list
        transfers = material_transfer.objects.all()
        transfers = transfers.order_by('material_transfer_id')

        pages = Paginator(transfers, 10)
        page_number = request.GET.get('page')

        transfers_obj = pages.get_page(page_number)

        context = {

            'transfers': transfers,
            'transfers_obj': transfers_obj
        }

        return render(request, 'main/stock/transfers/transfers_list.html' , context)

def stock_status(request):

    

    #get total purchases value
        
    total_purchases = 0
    purchases = material_purchase.objects.all()
    for p in purchases:
        total_purchases = total_purchases + (p.material_purchase_quantity * p.material_purchase_cost)

    #get total sells value
        
    total_sells = 0
    sells = material_sale.objects.all()
    for s in sells:
        total_sells = total_sells + (s.material_sale_quantity * s.material_sale_price)

    
    #return the context
        
    context = {
        'total_purchases': total_purchases,
        'total_sells': total_sells,
    }
    
        






    return render(request, 'main/stock/stock_status.html' , context)