console.log('buy_materials.js loaded');

let material_data = {}





let mat 


PaymentMethod = document.getElementById("payment_method");


PaymentMethod.addEventListener("change", function () {
    
        // get the value of the selected option
        const method = PaymentMethod.value;



        if (method == "partial") {
            
            amountBox = document.getElementById("amountBox");
            amountBox.style.display = "block";
            


        } else {
            amountBox = document.getElementById("amountBox");
            amountBox.style.display = "none";
        }
    
    
    }

);

const supplierField = document.getElementById("supplier");
const materialsField = document.getElementById("materials");
const quantity = document.getElementById("quantity");
const price = document.getElementById("price");
const total = document.getElementById("total");
const amountToPay = document.getElementById("amountToPay");




materialsField.addEventListener("change", function () {
        
            // get the value of the selected option
            const material_id = materialsField.value;
            console.log(material_id);

            // send a request to the server
            fetch("/get_suppliers/"+material_id+"/", {
                method: "POST",
            })
                .then((res) => res.json())
                .then((data) => {

                    supplier.innerHTML = `<option selected value="" selected disabled>Choose supplier</option> \n`;
                    
                    data.forEach((supplier) => {
                        supplierField.innerHTML += `
                        <option value="${supplier.id}">${supplier.name}</option>
                        `;
                    });

                    
                });
            
            

            
        
        }
    );

supplierField.addEventListener("change", function () {

    console.log(supplierField.value);

    // get the value of the selected option
    const supplier_id = supplierField.value;

    fetch("/get_materials/"+supplier_id+"/", { method: "POST",})
        .then((res) => res.json())
        .then((data) => {material_data = data;});


        console.log(material_data);



    
    
    // look for the material in the material_data 
    for (let i = 0; i < material_data.length; i++) {

        console.log(material_data[i].id);
        

        if (material_data[i].id == materialsField.value) {
            console.log("found");
            mat = material_data[i];
            break;
        }
    }

    price.innerHTML = mat.price + " DZ";

}
);


quantity.addEventListener("keyup", function () {

    // get the value of the selected option
    const quantity_value = quantity.value;
    console.log(quantity_value);
    
    total.innerHTML = mat.price * quantity_value + " DZ";

}

);





    


