from django.db import models


class center(models.Model):
    center_id = models.AutoField(primary_key=True)
    center_name = models.CharField(max_length=50)
    center_designation = models.CharField(max_length=50)

    def __str__(self):
        return self.center_name
    
class product(models.Model):
    product_id = models.AutoField(primary_key=True)
    product_name = models.CharField(max_length=50)
    product_price = models.IntegerField()
    product_quantity = models.IntegerField()
    product_category = models.CharField(max_length=50, default="")

    def __str__(self):
        return self.product_name




class employee(models.Model):
    employee_id = models.AutoField(primary_key=True)
    employee_name = models.CharField(max_length=50)
    employee_address = models.CharField(max_length=50, default="")
    employee_phone = models.CharField(max_length=50, default="")
    employee_email = models.CharField(max_length=50, default="")
    center_id = models.ForeignKey(center, on_delete=models.CASCADE)
    employee_daily_salary = models.IntegerField(default=0)
    employee_absences = models.IntegerField(default=0)
    employee_advanced_salary = models.IntegerField(default=0)
    employee_last_salary_date = models.DateField(default="2020-01-01")


    def __str__(self):
        return self.employee_name



class material(models.Model):
    material_id = models.AutoField(primary_key=True)
    material_name = models.CharField(max_length=50)
    material_quantity = models.IntegerField()
    material_description = models.CharField(max_length=200)

    def __str__(self):
        return self.material_name
    

class supplier(models.Model):
    supplier_id = models.AutoField(primary_key=True)
    supplier_name = models.CharField(max_length=50)
    supplier_address = models.CharField(max_length=50)
    supplier_phone = models.IntegerField()
    supplier_email = models.CharField(max_length=50)
    supplier_balance = models.IntegerField(default=0)

    def __str__(self):
        return self.supplier_name
    

class mat_supp(models.Model):
    mat_supp_id = models.AutoField(primary_key=True)
    material_id = models.ForeignKey(material, on_delete=models.CASCADE)
    supplier_id = models.ForeignKey(supplier, on_delete=models.CASCADE)
    mat_supp_price = models.IntegerField()

    def __str__(self):
        return str(self.mat_supp_id)
    

class material_purchase(models.Model):
    material_purchase_id = models.AutoField(primary_key=True)
    material_purchase_material = models.ForeignKey(material, on_delete=models.CASCADE , default=None)
    material_purchase_supplier = models.ForeignKey(supplier, on_delete=models.CASCADE , default=None)
    material_purchase_quantity = models.IntegerField()
    material_purchase_cost = models.IntegerField()
    material_purchase_date = models.DateField()

    def __str__(self):
        return str(self.material_purchase_id)
    


    

class material_transfer(models.Model):
    material_transfer_id = models.AutoField(primary_key=True)
    material_transfer_material = models.ForeignKey(material, on_delete=models.CASCADE , default=None)
    material_transfer_center = models.ForeignKey(center, on_delete=models.CASCADE , default=None)
    material_transfer_quantity = models.IntegerField()
    material_transfer_cost = models.IntegerField()
    material_transfer_date = models.DateField()

    def __str__(self):
        return str(self.material_transfer_id)
    

class client(models.Model):
    client_id = models.AutoField(primary_key=True)
    client_name = models.CharField(max_length=50)
    client_address = models.CharField(max_length=50)
    client_balance = models.IntegerField(default=0)

    def __str__(self):
        return self.client_name
    

class material_sale(models.Model):
    material_sale_id = models.AutoField(primary_key=True)
    material_sale_material = models.ForeignKey(material, on_delete=models.CASCADE , default=None)
    material_sale_client = models.ForeignKey(client, on_delete=models.CASCADE , default=None)
    material_sale_quantity = models.IntegerField()
    material_sale_price = models.IntegerField()
    material_sale_date = models.DateField()

    def __str__(self):
        return str(self.material_sale_id)
    

class sale(models.Model):
    sale_id = models.AutoField(primary_key=True)
    sale_client = models.ForeignKey(client, on_delete=models.CASCADE , default=None)
    sale_center = models.ForeignKey(center, on_delete=models.CASCADE , default=None)
    sale_product = models.ForeignKey(product, on_delete=models.CASCADE , default=None)
    sale_date = models.DateField()
    sale_amount = models.IntegerField()

    def __str__(self):
        return str(self.sale_id)






