from django.shortcuts import render

from app.models import center , employee , sale

from django.core.paginator import Paginator



def center(request , c):

    employees = employee.objects.filter(center_id = c)
    employees = employees.order_by("employee_id")
    pages = Paginator(employees, 5)
    page_number = request.GET.get("page")
    employees_obj = pages.get_page(page_number)

    #calculate total salary
    total_salary = {}

    for e in employees:
        total_salary[e.employee_id] = e.employee_daily_salary * ( 30 - e.employee_absences ) + e.employee_advanced_salary



    #get sales of center
        
    sales = sale.objects.filter(sale_center_id = c)
    sales = sales.order_by("sale_id")
    pages = Paginator(sales, 5)
    page_number = request.GET.get("page")

    sales_obj = pages.get_page(page_number)

        





    context = {
        'center_id': c,
        'employees': employees,
        'employees_obj': employees_obj,
        'total_salary': total_salary,
        'sales_obj': sales_obj,
    }




    return render(request, 'main/manage_centers/center.html' , context )