
# this file is used to generate the data for the database based on the models in models.py for all the apps


# data for centers 


centers = [
    {"center_id": "1", "center_name": "Center 1", "center_designation": "Main Center"},
    {"center_id": "2", "center_name": "Center 2", "center_designation": "Regional Center"},
    {"center_id": "3", "center_name": "Center 3", "center_designation": "Local Center"}
]


# data for clients (client_id, client_name, client_address, client_balance) with fake names and emails

clients = [
    {"client_id": 1, "client_name": "John Doe", "client_address": "123 Main Street, Cityville", "client_balance": 5000},
    {"client_id": 2, "client_name": "Jane Smith", "client_address": "456 Oak Avenue, Townsville", "client_balance": 0},
    {"client_id": 3, "client_name": "Bob Johnson", "client_address": "789 Pine Road, Villagetown", "client_balance": 8000},
    {"client_id": 4, "client_name": "Alice Brown", "client_address": "101 Elm Lane, Hamletville", "client_balance": 0},
    {"client_id": 5, "client_name": "David Wilson", "client_address": "202 Cedar Court, Boroughburg", "client_balance": 7000},
    {"client_id": 6, "client_name": "Emily Davis", "client_address": "303 Maple Street, District City", "client_balance": 2000},
    {"client_id": 7, "client_name": "Chris Taylor", "client_address": "404 Birch Road, Metropolis", "client_balance": 0},
    {"client_id": 8, "client_name": "Sophia White", "client_address": "505 Spruce Avenue, Megatown", "client_balance": 6000},
    {"client_id": 9, "client_name": "Michael Green", "client_address": "606 Fir Lane, Capital City", "client_balance": 3500},
    {"client_id": 10, "client_name": "Olivia Miller", "client_address": "707 Pine Court, City Center", "client_balance": 10000},
]



# data for supliers (supplier_id, supplier_name, supplier_address, supplier_phone, supplier_email) with fake names and emails

suppliers = [
    {"supplier_id": "101", "supplier_name": "NatureCraft Materials", "supplier_address": "234 Greenway Street, Eco City, USA", "supplier_phone": "+15551112233", "supplier_email": "sales@naturecraftmaterials.com"},
    {"supplier_id": "102", "supplier_name": "AgroTech Innovations", "supplier_address": "567 Harvest Lane, Farmville, USA", "supplier_phone": "+15552223344", "supplier_email": "info@agrotechinnovations.net"},
    {"supplier_id": "103", "supplier_name": "WoodSource International", "supplier_address": "789 Timber Avenue, Timberland, USA", "supplier_phone": "+15553334455", "supplier_email": "sales@woodsourceintl.com"},
    {"supplier_id": "104", "supplier_name": "EcoFibers Ltd.", "supplier_address": "876 Eco Street, Sustainable City, USA", "supplier_phone": "+155544445566", "supplier_email": "contact@ecofibersltd.com"},
    {"supplier_id": "105", "supplier_name": "GreenHarvest Seeds", "supplier_address": "101 Seedling Lane, Growtown, USA", "supplier_phone": "+15555556677", "supplier_email": "info@greenharvestseeds.org"},
    {"supplier_id": "106", "supplier_name": "BambooCraft Suppliers", "supplier_address": "222 Bamboo Boulevard, Bamboo City, USA", "supplier_phone": "+15556667788", "supplier_email": "sales@bamboocraftsuppliers.com"},
    {"supplier_id": "107", "supplier_name": "NaturalOils Extracts", "supplier_address": "333 Aromatics Street, Fragranceville, USA", "supplier_phone": "+15557778899", "supplier_email": "info@naturaloils.com"},
    {"supplier_id": "108", "supplier_name": "GreenBuild Solutions", "supplier_address": "444 Sustainable Way, Greentech, USA", "supplier_phone": "+15558889900", "supplier_email": "contact@greenbuildsolutions.org"},
    {"supplier_id": "109", "supplier_name": "RecycleCraft Materials", "supplier_address": "555 Recycling Road, Recycleville, USA", "supplier_phone": "+15559990011", "supplier_email": "sales@recyclecraftmaterials.com"},
    {"supplier_id": "110", "supplier_name": "HerbalHarmony Farms", "supplier_address": "666 Herb Lane, Botanical City, USA", "supplier_phone": "+15550011122", "supplier_email": "info@herbalharmonyfarms.com"}
]



# data for materials (material_id, material_name, material_description, material_unit, material_price) with fake names and descriptions

materials = [
    {"material_id": "201", "material_name": "Organic Cotton", "material_description": "High-quality organic cotton for textile production", "material_unit": "kg", "material_price": 5.50, "material_quantity": 100},
    {"material_id": "202", "material_name": "Recycled Wood", "material_description": "Sustainably sourced recycled wood for furniture", "material_unit": "m³", "material_price": 120.00, "material_quantity": 600},
    {"material_id": "203", "material_name": "Bamboo Strips", "material_description": "Natural bamboo strips for craft and construction", "material_unit": "bundle", "material_price": 8.75, "material_quantity": 100},
    {"material_id": "204", "material_name": "Essential Oils Set", "material_description": "Assorted set of essential oils for cosmetic and aromatherapy use", "material_unit": "set", "material_price": 25.00, "material_quantity": 150},
    {"material_id": "205", "material_name": "Recycled Paper", "material_description": "Eco-friendly recycled paper for packaging", "material_unit": "ream", "material_price": 4.50, "material_quantity": 260},
    {"material_id": "206", "material_name": "Herbal Seeds Mix", "material_description": "A mix of organic herbal seeds for cultivation", "material_unit": "packet", "material_price": 2.25, "material_quantity": 1000},
    {"material_id": "207", "material_name": "Natural Dyes Kit", "material_description": "Kit containing natural dyes for fabric coloring", "material_unit": "kit", "material_price": 15.00, "material_quantity": 0},
    {"material_id": "208", "material_name": "BioFertilizer", "material_description": "Organic biofertilizer for sustainable farming", "material_unit": "liter", "material_price": 7.50, "material_quantity": 500},
    {"material_id": "209", "material_name": "Timber Planks", "material_description": "High-quality timber planks for construction", "material_unit": "piece", "material_price": 18.00, "material_quantity": 1600},
    {"material_id": "210", "material_name": "Greenhouse Plastic Sheets", "material_description": "Durable plastic sheets for greenhouse construction", "material_unit": "roll", "material_price": 30.00, "material_quantity": 300}
]


# data for material suppliers (material_id, supplier_id, mat_supp_price) with fake prices


mat_supps = [
    {"material_id": "201", "supplier_id": "101", "mat_supp_price": 600},
    {"material_id": "202", "supplier_id": "102", "mat_supp_price": 13000},
    {"material_id": "203", "supplier_id": "103", "mat_supp_price": 900},
    {"material_id": "204", "supplier_id": "104", "mat_supp_price": 2800},
    {"material_id": "205", "supplier_id": "105", "mat_supp_price": 500},
    {"material_id": "206", "supplier_id": "106", "mat_supp_price": 250},
    {"material_id": "207", "supplier_id": "107", "mat_supp_price": 1600},
    {"material_id": "208", "supplier_id": "108", "mat_supp_price": 800},
    {"material_id": "209", "supplier_id": "109", "mat_supp_price": 2000},
    {"material_id": "210", "supplier_id": "110", "mat_supp_price": 3500},
    {"material_id": "201", "supplier_id": "102", "mat_supp_price": 580},
    {"material_id": "202", "supplier_id": "103", "mat_supp_price": 12500},
    {"material_id": "203", "supplier_id": "104", "mat_supp_price": 800},
    {"material_id": "204", "supplier_id": "105", "mat_supp_price": 2700},
    {"material_id": "205", "supplier_id": "106", "mat_supp_price": 480},
    {"material_id": "206", "supplier_id": "107", "mat_supp_price": 230},
    {"material_id": "207", "supplier_id": "108", "mat_supp_price": 1500},
    {"material_id": "208", "supplier_id": "109", "mat_supp_price": 750},
    {"material_id": "209", "supplier_id": "110", "mat_supp_price": 1900},
    {"material_id": "210", "supplier_id": "101", "mat_supp_price": 3300},
]

# data for material purchases (material_purchase_id, material_purchase_material, material_purchase_supplier, material_purchase_quantity, material_purchase_date) with fake dates

material_purchases = [
    {"material_purchase_id": 301, "material_purchase_material": "201", "material_purchase_supplier": "101", "material_purchase_quantity": 500, "material_purchase_date": "2023-03-10", "material_purchase_cost": 9000},
    {"material_purchase_id": 302, "material_purchase_material": "202", "material_purchase_supplier": "102", "material_purchase_quantity": 100, "material_purchase_date": "2023-04-15", "material_purchase_cost": 500},
    {"material_purchase_id": 303, "material_purchase_material": "203", "material_purchase_supplier": "103", "material_purchase_quantity": 200, "material_purchase_date": "2023-05-20", "material_purchase_cost": 6000},
    {"material_purchase_id": 304, "material_purchase_material": "204", "material_purchase_supplier": "104", "material_purchase_quantity": 50, "material_purchase_date": "2023-06-25", "material_purchase_cost": 8000},
    {"material_purchase_id": 305, "material_purchase_material": "205", "material_purchase_supplier": "105", "material_purchase_quantity": 300, "material_purchase_date": "2023-07-30", "material_purchase_cost": 8000},
    {"material_purchase_id": 306, "material_purchase_material": "206", "material_purchase_supplier": "106", "material_purchase_quantity": 150, "material_purchase_date": "2023-08-05", "material_purchase_cost": 6900},
    {"material_purchase_id": 307, "material_purchase_material": "207", "material_purchase_supplier": "107", "material_purchase_quantity": 80, "material_purchase_date": "2023-09-10", "material_purchase_cost": 3900},
    {"material_purchase_id": 308, "material_purchase_material": "208", "material_purchase_supplier": "108", "material_purchase_quantity": 120, "material_purchase_date": "2023-10-15", "material_purchase_cost": 2200},
    {"material_purchase_id": 309, "material_purchase_material": "209", "material_purchase_supplier": "109", "material_purchase_quantity": 250, "material_purchase_date": "2023-11-20", "material_purchase_cost": 8000},
    {"material_purchase_id": 310, "material_purchase_material": "210", "material_purchase_supplier": "110", "material_purchase_quantity": 75, "material_purchase_date": "2023-12-25", "material_purchase_cost": 3650},
    {"material_purchase_id": 311, "material_purchase_material": "201", "material_purchase_supplier": "102", "material_purchase_quantity": 450, "material_purchase_date": "2024-01-05", "material_purchase_cost": 3500},
    {"material_purchase_id": 312, "material_purchase_material": "202", "material_purchase_supplier": "103", "material_purchase_quantity": 90, "material_purchase_date": "2024-02-10", "material_purchase_cost": 9050},
    {"material_purchase_id": 313, "material_purchase_material": "203", "material_purchase_supplier": "104", "material_purchase_quantity": 180, "material_purchase_date": "2024-03-15", "material_purchase_cost": 2800},
    {"material_purchase_id": 314, "material_purchase_material": "204", "material_purchase_supplier": "105", "material_purchase_quantity": 30, "material_purchase_date": "2024-04-20", "material_purchase_cost": 1100},
    {"material_purchase_id": 315, "material_purchase_material": "205", "material_purchase_supplier": "106", "material_purchase_quantity": 270, "material_purchase_date": "2024-05-25", "material_purchase_cost": 3600},
    {"material_purchase_id": 316, "material_purchase_material": "206", "material_purchase_supplier": "107", "material_purchase_quantity": 120, "material_purchase_date": "2024-06-30", "material_purchase_cost": 6700},
    {"material_purchase_id": 317, "material_purchase_material": "207", "material_purchase_supplier": "108", "material_purchase_quantity": 60, "material_purchase_date": "2024-07-05", "material_purchase_cost": 3400},
    {"material_purchase_id": 318, "material_purchase_material": "208", "material_purchase_supplier": "109", "material_purchase_quantity": 90, "material_purchase_date": "2024-08-10", "material_purchase_cost": 4800},
    {"material_purchase_id": 319, "material_purchase_material": "209", "material_purchase_supplier": "110", "material_purchase_quantity": 200, "material_purchase_date": "2024-09-15", "material_purchase_cost": 6800},
    {"material_purchase_id": 320, "material_purchase_material": "210", "material_purchase_supplier": "101", "material_purchase_quantity": 60, "material_purchase_date": "2024-10-20", "material_purchase_cost": 9850},
]


# data for material transfers (material_transfer_id, material_transfer_material, material_transfer_center, material_transfer_quantity, material_transfer_date) with fake dates


material_transfers = [
    {"material_transfer_id": 401, "material_transfer_material": "201", "material_transfer_center": 1, "material_transfer_quantity": 200, "material_transfer_date": "2023-03-10", "material_transfer_cost": 7200},
    {"material_transfer_id": 402, "material_transfer_material": "202", "material_transfer_center": 2, "material_transfer_quantity": 50, "material_transfer_date": "2023-04-15", "material_transfer_cost": 1000},
    {"material_transfer_id": 403, "material_transfer_material": "203", "material_transfer_center": 3, "material_transfer_quantity": 100, "material_transfer_date": "2023-05-20", "material_transfer_cost": 1200},
    {"material_transfer_id": 404, "material_transfer_material": "204", "material_transfer_center": 1, "material_transfer_quantity": 20, "material_transfer_date": "2023-06-25", "material_transfer_cost": 1000},
    {"material_transfer_id": 405, "material_transfer_material": "205", "material_transfer_center": 2, "material_transfer_quantity": 150, "material_transfer_date": "2023-07-30", "material_transfer_cost": 1000},
    {"material_transfer_id": 406, "material_transfer_material": "206", "material_transfer_center": 3, "material_transfer_quantity": 80, "material_transfer_date": "2023-08-05", "material_transfer_cost": 3000},
    {"material_transfer_id": 407, "material_transfer_material": "207", "material_transfer_center": 1, "material_transfer_quantity": 30, "material_transfer_date": "2023-09-10", "material_transfer_cost": 1000},
    {"material_transfer_id": 408, "material_transfer_material": "208", "material_transfer_center": 2, "material_transfer_quantity": 40, "material_transfer_date": "2023-10-15", "material_transfer_cost": 1000},
    {"material_transfer_id": 409, "material_transfer_material": "209", "material_transfer_center": 3, "material_transfer_quantity": 70, "material_transfer_date": "2023-11-20", "material_transfer_cost": 6000},
    {"material_transfer_id": 410, "material_transfer_material": "210", "material_transfer_center": 1, "material_transfer_quantity": 10, "material_transfer_date": "2023-12-25", "material_transfer_cost": 1000},
    {"material_transfer_id": 411, "material_transfer_material": "201", "material_transfer_center": 2, "material_transfer_quantity": 180, "material_transfer_date": "2024-01-05", "material_transfer_cost": 1000},
    {"material_transfer_id": 412, "material_transfer_material": "202", "material_transfer_center": 3, "material_transfer_quantity": 30, "material_transfer_date": "2024-02-10", "material_transfer_cost": 5000},
    {"material_transfer_id": 413, "material_transfer_material": "203", "material_transfer_center": 1, "material_transfer_quantity": 60, "material_transfer_date": "2024-03-15", "material_transfer_cost": 1000},
    {"material_transfer_id": 414, "material_transfer_material": "204", "material_transfer_center": 2, "material_transfer_quantity": 15, "material_transfer_date": "2024-04-20", "material_transfer_cost": 1000},
    {"material_transfer_id": 415, "material_transfer_material": "205", "material_transfer_center": 3, "material_transfer_quantity": 120, "material_transfer_date": "2024-05-25", "material_transfer_cost": 15000},
    {"material_transfer_id": 416, "material_transfer_material": "206", "material_transfer_center": 1, "material_transfer_quantity": 50, "material_transfer_date": "2024-06-30", "material_transfer_cost": 1000},
    {"material_transfer_id": 417, "material_transfer_material": "207", "material_transfer_center": 2, "material_transfer_quantity": 25, "material_transfer_date": "2024-07-05", "material_transfer_cost": 1800},
    {"material_transfer_id": 418, "material_transfer_material": "208", "material_transfer_center": 3, "material_transfer_quantity": 35, "material_transfer_date": "2024-08-10", "material_transfer_cost": 1000},
    {"material_transfer_id": 419, "material_transfer_material": "209", "material_transfer_center": 1, "material_transfer_quantity": 90, "material_transfer_date": "2024-09-15", "material_transfer_cost": 2000},
    {"material_transfer_id": 420, "material_transfer_material": "210", "material_transfer_center": 2, "material_transfer_quantity": 5, "material_transfer_date": "2024-10-20", "material_transfer_cost": 2500},
]


# data for material sales (material_sale_id, material_sale_material, material_sale_client, material_sale_quantity, material_sale_date) with fake dates



material_sales = [
    {"material_sale_id": 501, "material_sale_material": "201", "material_sale_client": 1, "material_sale_quantity": 150, "material_sale_date": "2023-03-10", "material_sale_price": 500},
    {"material_sale_id": 502, "material_sale_material": "202", "material_sale_client": 2, "material_sale_quantity": 30, "material_sale_date": "2023-04-15", "material_sale_price": 500},
    {"material_sale_id": 503, "material_sale_material": "203", "material_sale_client": 3, "material_sale_quantity": 80, "material_sale_date": "2023-05-20", "material_sale_price": 500},
    {"material_sale_id": 504, "material_sale_material": "204", "material_sale_client": 1, "material_sale_quantity": 15, "material_sale_date": "2023-06-25", "material_sale_price": 500},
    {"material_sale_id": 505, "material_sale_material": "205", "material_sale_client": 2, "material_sale_quantity": 100, "material_sale_date": "2023-07-30", "material_sale_price": 500},
    {"material_sale_id": 506, "material_sale_material": "206", "material_sale_client": 3, "material_sale_quantity": 45, "material_sale_date": "2023-08-05", "material_sale_price": 500},
    {"material_sale_id": 507, "material_sale_material": "207", "material_sale_client": 1, "material_sale_quantity": 20, "material_sale_date": "2023-09-10", "material_sale_price": 500},
    {"material_sale_id": 508, "material_sale_material": "208", "material_sale_client": 2, "material_sale_quantity": 25, "material_sale_date": "2023-10-15", "material_sale_price": 500},
    {"material_sale_id": 509, "material_sale_material": "209", "material_sale_client": 3, "material_sale_quantity": 60, "material_sale_date": "2023-11-20", "material_sale_price": 500},
    {"material_sale_id": 510, "material_sale_material": "210", "material_sale_client": 1, "material_sale_quantity": 8, "material_sale_date": "2023-12-25", "material_sale_price": 500},
    {"material_sale_id": 511, "material_sale_material": "201", "material_sale_client": 2, "material_sale_quantity": 120, "material_sale_date": "2024-01-05", "material_sale_price": 500},
    {"material_sale_id": 512, "material_sale_material": "202", "material_sale_client": 3, "material_sale_quantity": 18, "material_sale_date": "2024-02-10", "material_sale_price": 500},
    {"material_sale_id": 513, "material_sale_material": "203", "material_sale_client": 1, "material_sale_quantity": 40, "material_sale_date": "2024-03-15", "material_sale_price": 500},
    {"material_sale_id": 514, "material_sale_material": "204", "material_sale_client": 2, "material_sale_quantity": 10, "material_sale_date": "2024-04-20", "material_sale_price": 500},
    {"material_sale_id": 515, "material_sale_material": "205", "material_sale_client": 3, "material_sale_quantity": 75, "material_sale_date": "2024-05-25", "material_sale_price": 500},
    {"material_sale_id": 516, "material_sale_material": "206", "material_sale_client": 1, "material_sale_quantity": 35, "material_sale_date": "2024-06-30", "material_sale_price": 500},
    {"material_sale_id": 517, "material_sale_material": "207", "material_sale_client": 2, "material_sale_quantity": 12, "material_sale_date": "2024-07-05", "material_sale_price": 500},
    {"material_sale_id": 518, "material_sale_material": "208", "material_sale_client": 3, "material_sale_quantity": 18, "material_sale_date": "2024-08-10", "material_sale_price": 500},
    {"material_sale_id": 519, "material_sale_material": "209", "material_sale_client": 1, "material_sale_quantity": 50, "material_sale_date": "2024-09-15", "material_sale_price": 500},
    {"material_sale_id": 520, "material_sale_material": "210", "material_sale_client": 2, "material_sale_quantity": 5, "material_sale_date": "2024-10-20", "material_sale_price": 500},
]



# data for products (product_id, product_name, product_price, product_quantity, product_category) with fake names and categories

products = [
    {"product_id": 601, "product_name": "EcoCraft Table", "product_price": 150, "product_quantity": 25, "product_category": "Furniture"},
    {"product_id": 602, "product_name": "Bamboo Wall Art", "product_price": 80, "product_quantity": 50, "product_category": "Decor"},
    {"product_id": 603, "product_name": "Herbal Wellness Kit", "product_price": 30, "product_quantity": 100, "product_category": "Wellness"},
    {"product_id": 604, "product_name": "Recycled Paper Notebook", "product_price": 5, "product_quantity": 200, "product_category": "Stationery"},
    {"product_id": 605, "product_name": "Organic Cotton T-shirt", "product_price": 20, "product_quantity": 75, "product_category": "Apparel"},
    {"product_id": 606, "product_name": "Wooden Plant Stand", "product_price": 45, "product_quantity": 30, "product_category": "Gardening"},
    {"product_id": 607, "product_name": "Natural Fragrance Set", "product_price": 15, "product_quantity": 50, "product_category": "Home Fragrance"},
    {"product_id": 608, "product_name": "Bamboo Cutlery Set", "product_price": 12, "product_quantity": 100, "product_category": "Kitchenware"},
    {"product_id": 609, "product_name": "Recycled Glass Vase", "product_price": 25, "product_quantity": 40, "product_category": "Decor"},
    {"product_id": 610, "product_name": "Herbal Tea Sampler", "product_price": 8, "product_quantity": 120, "product_category": "Beverages"},
    {"product_id": 611, "product_name": "Eco-friendly Backpack", "product_price": 40, "product_quantity": 60, "product_category": "Apparel"},
    {"product_id": 612, "product_name": "Sustainable Wooden Toys Set", "product_price": 18, "product_quantity": 80, "product_category": "Toys"},
    {"product_id": 613, "product_name": "Recycled Plastic Organizer", "product_price": 10, "product_quantity": 150, "product_category": "Office Supplies"},
    {"product_id": 614, "product_name": "Natural Fiber Rug", "product_price": 60, "product_quantity": 20, "product_category": "Home Decor"},
    {"product_id": 615, "product_name": "Herbal Shampoo Bar", "product_price": 6, "product_quantity": 200, "product_category": "Personal Care"},
    {"product_id": 616, "product_name": "Upcycled Denim Tote Bag", "product_price": 15, "product_quantity": 50, "product_category": "Accessories"},
    {"product_id": 617, "product_name": "Biodegradable Plant Pots", "product_price": 8, "product_quantity": 120, "product_category": "Gardening"},
    {"product_id": 618, "product_name": "EcoCraft Wall Clock", "product_price": 25, "product_quantity": 30, "product_category": "Decor"},
    {"product_id": 619, "product_name": "Organic Lip Balm Set", "product_price": 4, "product_quantity": 250, "product_category": "Personal Care"},
    {"product_id": 620, "product_name": "Reusable Beeswax Wraps", "product_price": 12, "product_quantity": 100, "product_category": "Kitchenware"},
    {"product_id": 621, "product_name": "Bamboo Laptop Stand", "product_price": 30, "product_quantity": 40, "product_category": "Office Accessories"},
    {"product_id": 622, "product_name": "Recycled Glass Candle Holder", "product_price": 8, "product_quantity": 80, "product_category": "Home Decor"},
    {"product_id": 623, "product_name": "Natural Wooden Coasters Set", "product_price": 10, "product_quantity": 100, "product_category": "Kitchenware"},
    {"product_id": 624, "product_name": "Organic Cotton Pillow Cover", "product_price": 15, "product_quantity": 60, "product_category": "Home Textile"},
    {"product_id": 625, "product_name": "Herbal Infuser Water Bottle", "product_price": 18, "product_quantity": 50, "product_category": "Wellness"},
    {"product_id": 626, "product_name": "Upcycled Glass Earrings", "product_price": 12, "product_quantity": 120, "product_category": "Accessories"},
    {"product_id": 627, "product_name": "Biodegradable Dish Scrubber", "product_price": 5, "product_quantity": 200, "product_category": "Cleaning Supplies"},
    {"product_id": 628, "product_name": "Eco-friendly Yoga Mat", "product_price": 25, "product_quantity": 30, "product_category": "Fitness"},
    {"product_id": 629, "product_name": "Recycled Aluminum Water Bottle", "product_price": 20, "product_quantity": 70, "product_category": "Outdoor Gear"},
    {"product_id": 630, "product_name": "Sustainable Bamboo Toothbrush Set", "product_price": 6, "product_quantity": 150, "product_category": "Personal Care"},
]



# data for sales (sale_id, sale_client, sale_center, sale_product, sale_amount , sale_date ) with fake dates

sales = [
    {"sale_id": 701, "sale_client": 9, "sale_center": 1, "sale_product": 601, "sale_amount": 4500, "sale_date": "2023-03-10"},
    {"sale_id": 702, "sale_client": 5, "sale_center": 2, "sale_product": 602, "sale_amount": 2400, "sale_date": "2023-04-15"},
    {"sale_id": 703, "sale_client": 3, "sale_center": 3, "sale_product": 603, "sale_amount": 300, "sale_date": "2023-05-20"},
    {"sale_id": 704, "sale_client": 1, "sale_center": 1, "sale_product": 604, "sale_amount": 1000, "sale_date": "2023-06-25"},
    {"sale_id": 705, "sale_client": 4, "sale_center": 2, "sale_product": 605, "sale_amount": 1500, "sale_date": "2023-07-30"},
    {"sale_id": 706, "sale_client": 3, "sale_center": 3, "sale_product": 606, "sale_amount": 1350, "sale_date": "2023-08-05"},
    {"sale_id": 707, "sale_client": 1, "sale_center": 1, "sale_product": 607, "sale_amount": 600, "sale_date": "2023-09-10"},
    {"sale_id": 708, "sale_client": 7, "sale_center": 2, "sale_product": 608, "sale_amount": 1000, "sale_date": "2023-10-15"},
    {"sale_id": 709, "sale_client": 3, "sale_center": 3, "sale_product": 609, "sale_amount": 1500, "sale_date": "2023-11-20"},
    {"sale_id": 710, "sale_client": 1, "sale_center": 1, "sale_product": 610, "sale_amount": 80, "sale_date": "2023-12-25"},
    {"sale_id": 711, "sale_client": 2, "sale_center": 2, "sale_product": 611, "sale_amount": 2400, "sale_date": "2024-01-05"},
    {"sale_id": 712, "sale_client": 3, "sale_center": 3, "sale_product": 612, "sale_amount": 1440, "sale_date": "2024-02-10"},
    {"sale_id": 713, "sale_client": 6, "sale_center": 1, "sale_product": 613, "sale_amount": 300, "sale_date": "2024-03-15"},
    {"sale_id": 714, "sale_client": 8, "sale_center": 2, "sale_product": 614, "sale_amount": 1500, "sale_date": "2024-04-20"},
    {"sale_id": 715, "sale_client": 8, "sale_center": 3, "sale_product": 615, "sale_amount": 1200, "sale_date": "2024-05-25"},
    {"sale_id": 716, "sale_client": 1, "sale_center": 1, "sale_product": 616, "sale_amount": 750, "sale_date": "2024-06-30"},
    {"sale_id": 717, "sale_client": 2, "sale_center": 2, "sale_product": 617, "sale_amount": 96, "sale_date": "2024-07-05"},
    {"sale_id": 718, "sale_client": 3, "sale_center": 3, "sale_product": 618, "sale_amount": 750, "sale_date": "2024-08-10"},
    {"sale_id": 719, "sale_client": 2, "sale_center": 1, "sale_product": 619, "sale_amount": 1500, "sale_date": "2024-09-15"},
    {"sale_id": 720, "sale_client": 2, "sale_center": 2, "sale_product": 620, "sale_amount": 60, "sale_date": "2024-10-20"},
    {"sale_id": 721, "sale_client": 4, "sale_center": 3, "sale_product": 601, "sale_amount": 800, "sale_date": "2024-11-05"},
    {"sale_id": 722, "sale_client": 1, "sale_center": 1, "sale_product": 602, "sale_amount": 1200, "sale_date": "2024-12-10"},
    {"sale_id": 723, "sale_client": 2, "sale_center": 2, "sale_product": 603, "sale_amount": 500, "sale_date": "2020-01-15"},
    {"sale_id": 724, "sale_client": 3, "sale_center": 3, "sale_product": 604, "sale_amount": 3000, "sale_date": "2020-02-20"},
    {"sale_id": 725, "sale_client": 6, "sale_center": 1, "sale_product": 605, "sale_amount": 900, "sale_date": "2022-03-25"},
    {"sale_id": 726, "sale_client": 2, "sale_center": 2, "sale_product": 606, "sale_amount": 1800, "sale_date": "2021-04-30"},
    {"sale_id": 727, "sale_client": 3, "sale_center": 3, "sale_product": 607, "sale_amount": 750, "sale_date": "2021-05-05"},
    {"sale_id": 728, "sale_client": 6, "sale_center": 1, "sale_product": 608, "sale_amount": 600, "sale_date": "2020-06-10"},
    {"sale_id": 729, "sale_client": 2, "sale_center": 2, "sale_product": 609, "sale_amount": 1500, "sale_date": "2020-07-15"},
    {"sale_id": 730, "sale_client": 3, "sale_center": 3, "sale_product": 610, "sale_amount": 120, "sale_date": "2023-08-20"},
    {"sale_id": 731, "sale_client": 1, "sale_center": 1, "sale_product": 611, "sale_amount": 2400, "sale_date": "2020-09-25"},
    {"sale_id": 732, "sale_client": 6, "sale_center": 2, "sale_product": 612, "sale_amount": 480, "sale_date": "2021-10-30"},
    {"sale_id": 733, "sale_client": 3, "sale_center": 3, "sale_product": 613, "sale_amount": 600, "sale_date": "2021-11-04"},
    {"sale_id": 734, "sale_client": 1, "sale_center": 1, "sale_product": 614, "sale_amount": 1200, "sale_date": "2022-12-09"},
    {"sale_id": 735, "sale_client": 2, "sale_center": 2, "sale_product": 615, "sale_amount": 1500, "sale_date": "2020-01-14"},
    {"sale_id": 736, "sale_client": 9, "sale_center": 3, "sale_product": 616, "sale_amount": 750, "sale_date": "2020-02-19"},
    {"sale_id": 737, "sale_client": 7, "sale_center": 1, "sale_product": 617, "sale_amount": 96, "sale_date": "2020-03-26"},
    {"sale_id": 738, "sale_client": 2, "sale_center": 2, "sale_product": 618, "sale_amount": 750, "sale_date": "2020-04-01"},
    {"sale_id": 739, "sale_client": 3, "sale_center": 3, "sale_product": 619, "sale_amount": 1500, "sale_date": "2021-05-06"},
    {"sale_id": 740, "sale_client": 1, "sale_center": 1, "sale_product": 620, "sale_amount": 60, "sale_date": "2021-06-11"},
    {"sale_id": 741, "sale_client": 9, "sale_center": 2, "sale_product": 621, "sale_amount": 300, "sale_date": "2021-07-16"},
    {"sale_id": 742, "sale_client": 3, "sale_center": 3, "sale_product": 622, "sale_amount": 800, "sale_date": "2020-08-21"},
    {"sale_id": 743, "sale_client": 1, "sale_center": 1, "sale_product": 623, "sale_amount": 1000, "sale_date": "2022-09-26"},
    {"sale_id": 744, "sale_client": 2, "sale_center": 2, "sale_product": 624, "sale_amount": 240, "sale_date": "2022-10-01"},
    {"sale_id": 745, "sale_client": 3, "sale_center": 3, "sale_product": 625, "sale_amount": 1200, "sale_date": "2022-11-06"},
    {"sale_id": 746, "sale_client": 6, "sale_center": 1, "sale_product": 626, "sale_amount": 500, "sale_date": "2022-12-11"},
    {"sale_id": 747, "sale_client": 2, "sale_center": 2, "sale_product": 627, "sale_amount": 750, "sale_date": "2021-01-16"},
    {"sale_id": 748, "sale_client": 3, "sale_center": 3, "sale_product": 628, "sale_amount": 96, "sale_date": "2021-02-21"},
    {"sale_id": 749, "sale_client": 1, "sale_center": 1, "sale_product": 629, "sale_amount": 1200, "sale_date": "2021-03-26"},
    {"sale_id": 750, "sale_client": 5, "sale_center": 2, "sale_product": 630, "sale_amount": 500, "sale_date": "2020-04-30"},
]



# data for employees (employee_id, employee_name, employee_address, employee_phone, employee_email , center_id , employee_daily_salary , employee_absences  , employee_advanced_salary , employee_last_salary_date) with fake data

employees = [
    {"employee_id": 1, "employee_name": "Alex Turner", "employee_address": "123 Main Street, Cityville", "employee_phone": "+1234567890", "employee_email": "alex.turner@email.com", "center_id": 1, "employee_daily_salary": 100, "employee_absences": 2, "employee_advanced_salary": 500, "employee_last_salary_date": "2024-01-15"},
    {"employee_id": 2, "employee_name": "Emma Watson", "employee_address": "456 Oak Avenue, Townsville", "employee_phone": "+1987654321", "employee_email": "emma.watson@email.com", "center_id": 2, "employee_daily_salary": 120, "employee_absences": 1, "employee_advanced_salary": 600, "employee_last_salary_date": "2024-01-20"},
    {"employee_id": 3, "employee_name": "Ryan Reynolds", "employee_address": "789 Pine Road, Villagetown", "employee_phone": "+3456789012", "employee_email": "ryan.reynolds@email.com", "center_id": 3, "employee_daily_salary": 110, "employee_absences": 3, "employee_advanced_salary": 450, "employee_last_salary_date": "2024-01-25"},
    {"employee_id": 4, "employee_name": "Mia Johnson", "employee_address": "101 Elm Lane, Hamletville", "employee_phone": "+2345678901", "employee_email": "mia.johnson@email.com", "center_id": 1, "employee_daily_salary": 90, "employee_absences": 0, "employee_advanced_salary": 400, "employee_last_salary_date": "2024-01-10"},
    {"employee_id": 5, "employee_name": "Chris Hemsworth", "employee_address": "202 Cedar Court, Boroughburg", "employee_phone": "+4567890123", "employee_email": "chris.hemsworth@email.com", "center_id": 2, "employee_daily_salary": 130, "employee_absences": 2, "employee_advanced_salary": 700, "employee_last_salary_date": "2024-01-22"},
    {"employee_id": 6, "employee_name": "Natalie Portman", "employee_address": "303 Maple Street, District City", "employee_phone": "+5678901234", "employee_email": "natalie.portman@email.com", "center_id": 3, "employee_daily_salary": 95, "employee_absences": 1, "employee_advanced_salary": 300, "employee_last_salary_date": "2024-01-18"},
    {"employee_id": 7, "employee_name": "Tom Holland", "employee_address": "404 Birch Road, Metropolis", "employee_phone": "+6789012345", "employee_email": "tom.holland@email.com", "center_id": 1, "employee_daily_salary": 110, "employee_absences": 0, "employee_advanced_salary": 550, "employee_last_salary_date": "2024-01-15"},
    {"employee_id": 8, "employee_name": "Zendaya Coleman", "employee_address": "505 Spruce Avenue, Megatown", "employee_phone": "+7890123456", "employee_email": "zendaya.coleman@email.com", "center_id": 2, "employee_daily_salary": 120, "employee_absences": 3, "employee_advanced_salary": 600, "employee_last_salary_date": "2024-01-20"},
    {"employee_id": 9, "employee_name": "Robert Pattinson", "employee_address": "606 Fir Lane, Capital City", "employee_phone": "+8901234567", "employee_email": "robert.pattinson@email.com", "center_id": 3, "employee_daily_salary": 100, "employee_absences": 1, "employee_advanced_salary": 500, "employee_last_salary_date": "2024-01-25"},
    {"employee_id": 10, "employee_name": "Daisy Ridley", "employee_address": "707 Pine Court, City Center", "employee_phone": "+0123456789", "employee_email": "daisy.ridley@email.com", "center_id": 1, "employee_daily_salary": 110, "employee_absences": 2, "employee_advanced_salary": 600, "employee_last_salary_date": "2024-01-15"},
]





















#--------------------------------------

# generate the data for the database

#--------------------------------------

import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'HarvestHub.settings')

import django
django.setup()

from app.models import  product as Product , client as Client , center as Center , client as Client , supplier as Supplier , material as Material , mat_supp as MaterialSupplier , material_purchase as MaterialPurchase , material_transfer as MaterialTransfer , material_sale as MaterialSale , product as Product , sale as Sale , supplier as Supplier , employee as Employee




def populate():

    Sale.objects.all().delete()

    print("--------------------")

    print("Populating database")

    print("--------------------")

    # populate the centers

    for center in centers:
        c = Center.objects.get_or_create(center_id=center["center_id"], center_name=center["center_name"], center_designation=center["center_designation"])[0]
        c.save()

    print("Centers populated")

    # populate the clients

    for client in clients:
        c = Client.objects.get_or_create(client_id=client["client_id"], client_name=client["client_name"], client_address=client["client_address"], client_balance=client["client_balance"])[0]
        c.save()

    print("Clients populated")

    # populate the suppliers

    for supplier in suppliers:
        s = Supplier.objects.get_or_create(supplier_id=supplier["supplier_id"], supplier_name=supplier["supplier_name"], supplier_address=supplier["supplier_address"], supplier_phone=supplier["supplier_phone"], supplier_email=supplier["supplier_email"])[0]
        s.save()

    print("Suppliers populated")

    # populate the materials

    for material in materials:
        m = Material.objects.get_or_create(material_id=material["material_id"], material_name=material["material_name"], material_description=material["material_description"] , material_quantity = material["material_quantity"] )[0]
        m.save()

    print("Materials populated")

    # populate the material suppliers

    for mat_supp in mat_supps:
        m = Material.objects.get(material_id=mat_supp["material_id"])
        s = Supplier.objects.get(supplier_id=mat_supp["supplier_id"])
        ms = MaterialSupplier.objects.get_or_create(mat_supp_id=mat_supp["material_id"]+mat_supp["supplier_id"], material_id=m, supplier_id=s, mat_supp_price=mat_supp["mat_supp_price"])[0]
        ms.save()

    print("Material Suppliers populated")

    # populate the material purchases

    for material_purchase in material_purchases:
        m = Material.objects.get(material_id=material_purchase["material_purchase_material"])
        s = Supplier.objects.get(supplier_id=material_purchase["material_purchase_supplier"])
        mp = MaterialPurchase.objects.get_or_create(material_purchase_id=material_purchase["material_purchase_id"], material_purchase_material=m, material_purchase_supplier=s, material_purchase_quantity=material_purchase["material_purchase_quantity"], material_purchase_date=material_purchase["material_purchase_date"] , material_purchase_cost=material_purchase["material_purchase_cost"] )[0]
        mp.save()

    print("Material Purchases populated")

    # populate the material transfers

    for material_transfer in material_transfers:
        m = Material.objects.get(material_id=material_transfer["material_transfer_material"])
        c = Center.objects.get(center_id=material_transfer["material_transfer_center"])
        mt = MaterialTransfer.objects.get_or_create(material_transfer_id=material_transfer["material_transfer_id"], material_transfer_material=m, material_transfer_center=c, material_transfer_quantity=material_transfer["material_transfer_quantity"], material_transfer_date=material_transfer["material_transfer_date"] , material_transfer_cost = material_transfer["material_transfer_cost"] )[0] 
        mt.save()

    print("Material Transfers populated")

    # populate the material sales

    """ for material_sale in material_sales:
        m = Material.objects.get(material_id=material_sale["material_sale_material"])
        c = Client.objects.get(client_id=material_sale["material_sale_client"])
        ms = MaterialSale.objects.get_or_create(material_sale_id=material_sale["material_sale_id"], material_sale_material=m, material_sale_client=c, material_sale_quantity=material_sale["material_sale_quantity"], material_sale_date=material_sale["material_sale_date"], material_sale_price=material_sale["material_sale_price"])[0]
        ms.save()"""

    print("Material Sales populated")

    # populate the products

    for product in products:
        p = Product.objects.get_or_create(product_id=product["product_id"], product_name=product["product_name"], product_price=product["product_price"], product_quantity=product["product_quantity"], product_category=product["product_category"])[0]
        p.save()

    print("Products populated")

    # populate the sales

    for sale in sales:
        c = Client.objects.get(client_id=sale["sale_client"])
        p = Product.objects.get(product_id=sale["sale_product"])
        cen = sale["sale_center"]
        s = Sale.objects.get_or_create(sale_id=sale["sale_id"], sale_client=c, sale_product=p, sale_amount=sale["sale_amount"], sale_date=sale["sale_date"] , sale_center_id = cen )[0]
        s.save()

    
    # populate the employees
        
    for employee in employees:
        c = Center.objects.get(center_id=employee["center_id"])

        e = Employee.objects.get_or_create(
            employee_id=employee["employee_id"],
            employee_name=employee["employee_name"],
            employee_address=employee["employee_address"],
            employee_phone=employee["employee_phone"],
            employee_email=employee["employee_email"],
            center_id=c,  # Use the retrieved Center instance
            employee_daily_salary=employee["employee_daily_salary"],
            employee_absences=employee["employee_absences"],
            employee_advanced_salary=employee["employee_advanced_salary"],
            employee_last_salary_date=employee["employee_last_salary_date"]
        )[0]
        e.save()

    print("Sales populated")

  

    print("--------------------")

    print("Database populated")

    print("--------------------")


#--------------------------------------
    
# run the script
    
#--------------------------------------
    
if __name__ == '__main__':

    print("--------------------")

    print("Starting population script...")

    print("--------------------")

    populate()

    print("--------------------")

    print("Population script complete")

    print("--------------------")










