import datetime
from django.shortcuts import render
from app.models import product, supplier, center, employee, client
from django.contrib import messages
from django.contrib import messages
from app.models import product, client, employee, center, supplier
from django.core.paginator import Paginator
import json
from django.http import HttpResponse, JsonResponse


from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa




# ------------employee------------#


def employee_table(request):
    employees = employee.objects.all()
    employees = employees.order_by("employee_id")

    pages = Paginator(employees, 10)
    page_number = request.GET.get("page")

    employees_obj = pages.get_page(page_number)

    context = {"employees": employees, "employees_obj": employees_obj}

    return render(request, "main/manage_tables/tables/employee/employee.html", context)


def add_employee(request):
    if request.method == "GET":
        centers = center.objects.all()
        return render(
            request,
            "main/manage_tables/tables/employee/add_employee.html",
            {"centers": centers},
        )

    if request.method == "POST":
        context = {"data": request.POST}

        employee_name = request.POST.get("employee_name")
        if not employee_name:
            messages.error(request, "Employee name cannot be empty")
            return render(
                request, "main/manage_tables/tables/employee/add_employee.html", context
            )

        center_id = request.POST.get("center_id")
        if not center_id:
            messages.error(request, "Center ID cannot be empty")
            return render(
                request, "main/manage_tables/tables/employee/add_employee.html", context
            )

        employee_address = request.POST.get("address")
        if not employee_address:
            messages.error(request, "Employee address cannot be empty")
            return render(
                request, "main/manage_tables/tables/employee/add_employee.html", context
            )

        employee_phone = request.POST.get("phone")
        if not employee_phone:
            messages.error(request, "Employee phone cannot be empty")
            return render(
                request, "main/manage_tables/tables/employee/add_employee.html", context
            )

        employee_email = request.POST.get("email")
        if not employee_email:
            messages.error(request, "Employee email cannot be empty")
            return render(
                request, "main/manage_tables/tables/employee/add_employee.html", context
            )

        try:
            selected_center = center.objects.get(id=center_id)
        except center.DoesNotExist:
            messages.error(request, "Invalid center ID")
            return render(
                request, "main/manage_tables/tables/employee/add_employee.html", context
            )

        employee.objects.create(
            employee_name=employee_name,
            employee_address=employee_address,
            employee_phone=employee_phone,
            employee_email=employee_email,
            center_id=selected_center,
        )
        messages.success(request, "Employee added successfully")

        employees = employee.objects.all()
        employees = employees.order_by("employee_id")
        pages = Paginator(employees, 10)
        page_number = request.GET.get("page")
        employees_obj = pages.get_page(page_number)
        context = {"employees": employees, "employees_obj": employees_obj}

        return render(
            request, "main/manage_tables/tables/employee/employee.html", context
        )


def edit_employee(request, id):
    employee_instance = employee.objects.get(pk=id)
    context = {"id": id, "data": employee_instance}

    if request.method == "GET":
        return render(
            request, "main/manage_tables/tables/employee/edit_employee.html", context
        )

    if request.method == "POST":
        employee_name = request.POST.get("employee_name")
        if not employee_name:
            messages.error(request, "Client name cannot be empty")
            return render(
                request,
                "main/manage_tables/tables/employee/edit_employee.html",
                context,
            )

        employee_address = request.POST.get("address")
        if not employee_address:
            messages.error(request, "Client address cannot be empty")
            return render(
                request,
                "main/manage_tables/tables/employee/edit_employee.html",
                context,
            )

        employee_phone = request.POST.get("phone")
        if not employee_phone:
            messages.error(request, "Client phone cannot be empty")
            return render(
                request,
                "main/manage_tables/tables/employee/edit_employee.html",
                context,
            )

        employee_email = request.POST.get("email")
        if not employee_email:
            messages.error(request, "Client email cannot be empty")
            return render(
                request,
                "main/manage_tables/tables/employee/edit_employee.html",
                context,
            )

        employee_instance.employee_name = employee_name
        employee_instance.employee_address = employee_address
        employee_instance.employee_phone = employee_phone
        employee_instance.employee_email = employee_email
        employee_instance.save()
        messages.success(request, "Client updated successfully")

        employees = employee.objects.all()
        employees = employees.order_by("employee_id")
        pages = Paginator(employees, 10)
        page_number = request.GET.get("page")
        employees_obj = pages.get_page(page_number)
        context = {"employees": employees, "employees_obj": employees_obj}

        return render(
            request, "main/manage_tables/tables/employee/employee.html", context
        )


def delete_employee(request, id):
    employee_instance = employee.objects.get(pk=id)
    employee_instance.delete()
    messages.success(request, "Product deleted successfully")

    employees = employee.objects.all()
    employees = employees.order_by("employee_id")
    pages = Paginator(employees, 10)
    page_number = request.GET.get("page")
    employees_obj = pages.get_page(page_number)
    context = {"employees": employees, "employees_obj": employees_obj}
    return render(request, "main/manage_tables/tables/employee/employee.html", context)


def search_employee(request):
    if request.method == "POST":
        search_str = json.loads(request.body).get("searchText")

        employees = (
            employee.objects.filter(employee_name__icontains=search_str)
            | employee.objects.filter(employee_address__icontains=search_str)
            | employee.objects.filter(employee_phone__icontains=search_str)
            | employee.objects.filter(employee_email__icontains=search_str)
        )

        data = employees.values()

        return JsonResponse(list(data), safe=False)
