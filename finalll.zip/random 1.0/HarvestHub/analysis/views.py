from django.shortcuts import render
from app.models import *
from django.http import JsonResponse





def index(request):
    return render(request, 'main/analysis/analysis.html')



from django.db.models import Sum
from django.http import JsonResponse

def get_purchases_per_month(request, year):
    # For a specific year, get the total number of purchases per month

    # Get all the purchases for that year
    purchases = material_purchase.objects.filter(material_purchase_date__year=year)

    # Initialize a dictionary to store monthly totals
    monthly_totals = {}

    # Loop through each month and calculate the total quantity purchased
    for month in range(1, 13):
        total_quantity = purchases.filter(material_purchase_date__month=month).aggregate(Sum('material_purchase_quantity'))['material_purchase_quantity__sum']
        monthly_totals[month] = total_quantity if total_quantity else 0

    # Return the data as a JSON response
    return JsonResponse(monthly_totals)


def get_center_sales_stats (request, center):

    if center == 0:
        #get all the sales
        sales = sale.objects.all()
    else:
        #get all the sales for that center
        sales = sale.objects.filter(sale_center=center)


    #get the top products sold

    #get all the products
    products = product.objects.all()

    #create a dictionary to store the product name and the total sales amount
    product_sales = {}

    #for each product, get the total sales amount
    for i in products:
        product_sales[i.product_name] = 0
        for j in sales.filter(sale_product=i):
            product_sales[i.product_name] = product_sales[i.product_name] + j.sale_amount

    #sort the dictionary by the total sales amount
    product_sales = sorted(product_sales.items(), key=lambda x: x[1], reverse=True)

    #get the top 5 products

    product_sales = product_sales[:5]



    #get the top clients

    #get all the clients
    clients = client.objects.all()

    #create a dictionary to store the client name and the total sales amount
    client_sales = {}

    #for each client, get the number of sales made
    for i in clients:
        client_sales[i.client_name] = 0
        for j in sales.filter(sale_client=i):
            client_sales[i.client_name] = client_sales[i.client_name] + 1

    #sort the dictionary by the total sales amount
    client_sales = sorted(client_sales.items(), key=lambda x: x[1], reverse=True)
    #remove the ones with 0 sales
    client_sales = [i for i in client_sales if i[1] != 0]



    data = {
            'product_sales':product_sales,
            'client_sales':client_sales,
        }
    
    #print everything to check
    print('---------- product sales ----------')
    print(product_sales)
    print('---------- client sales ----------')
    print(client_sales)
    print('---------- data ----------')
    

    #return the data as a json response
    return JsonResponse(data)  
    

def get_top_suppliers (request):

    #get the top 3 suppliers based on the total purchases amount 

    #get all the suppliers
    suppliers = supplier.objects.all()

    #create a dictionary to store the supplier name and the total purchases amount
    supplier_purchases = {}

    #for each supplier, get the total purchases amount
    for i in suppliers:
        supplier_purchases[i.supplier_name] = 0
        for j in material_purchase.objects.filter(material_purchase_supplier=i):
            supplier_purchases[i.supplier_name] = supplier_purchases[i.supplier_name] + j.material_purchase_quantity

    #sort the dictionary by the total purchases amount
    supplier_purchases = sorted(supplier_purchases.items(), key=lambda x: x[1], reverse=True)

    #get the top 3 suppliers
    supplier_purchases = supplier_purchases[:3]

    print('---------- supplier purchases ----------')
    print(supplier_purchases)

    return JsonResponse(supplier_purchases, safe=False)

    
def get_year_sales_stats(request, year):
    # Get the total number of sales per month for that year

    # Get all the sales for that year
    sales = sale.objects.filter(sale_date__year=year)

    # Create a dictionary to store the sales count per month
    sales_per_month = {}

    # Iterate over each month and count the sales
    for month in range(1, 13):
        sales_per_month[month] = sales.filter(sale_date__month=month).count()

    

    # get the income per month
    # Create a dictionary to store the sales count per month
    income_per_month = {}
    


    # Iterate over each month and count the sales (income = sale_amount * product_price )
    for month in range(1, 13):
        income_per_month[month] = 0
        for j in sales.filter(sale_date__month=month):
            income_per_month[month] = income_per_month[month] + (j.sale_amount * j.sale_product.product_price)
    

    # put the data in a dict
    data = {
            'sales_per_month':sales_per_month,
            'income_per_month':income_per_month,
        }
    
   

    #return the data as a json response
    return JsonResponse(data)






    