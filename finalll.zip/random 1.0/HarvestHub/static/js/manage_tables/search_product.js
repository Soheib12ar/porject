console.log("search_product.js loaded");

const searchField = document.querySelector('#searchField');

const tableOutput = document.querySelector('.table-output');
tableOutput.style.display = 'none';

const appTable = document.querySelector('.app-table');
const paginationContainer = document.querySelector('.pagination-container');

const tbody = document.querySelector('.table-body');

const noResultsDiv = document.querySelector('.no-results');
noResultsDiv.style.display = 'none';




searchField.addEventListener('keyup', (e) => {

    const searchValue = e.target.value;

    if (searchValue.trim().length > 0) {

        paginationContainer.style.display = 'none';
        

        
        fetch('/manage_tables/search_product/', {
            body: JSON.stringify({ searchText: searchValue }),
            method: 'POST',
        })
            .then((res) => res.json())
            .then((data) => {


                tbody.innerHTML = "";


                appTable.style.display = 'none';

                tableOutput.style.display = 'block';
                
                if (data.length === 0) {
                    noResultsDiv.style.display = 'block';
                    tableOutput.style.display = 'none';
                }
                else {
                    noResultsDiv.style.display = 'none';
                    

                    data.forEach(item => {


                        tbody.innerHTML += `
                        <tr>
                            <td>${item.product_id}</td>
                            <td>${item.product_name}</td>
                            <td>${item.product_price}</td>
                            <td>${item.product_quantity}</td>
                            <td>${item.product_category}</td>
                            <td>
                                <a href="/manage_tables/edit_product/${item.product_id}" class="btn btn-secondary">Edit</a>
                                <a href="/manage_tables/delete_product/${item.product_id}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>


                        
                        `
                    });

                    

                }
           
            });

    }
    else {
        appTable.style.display = 'block';
        paginationContainer.style.display = 'block';
        tableOutput.style.display = 'none';
        noResultsDiv.style.display = 'none';
    }

});







