console.log("materials.js loaded");


const outputTable = document.querySelector(".table-output");

if (outputTable != null) {
    outputTable.style.display = "none";
}

















const appTable = document.querySelector('.app-table');
const paginationContainer = document.querySelector('.pagination-container');

const tbody = document.querySelector('.table-body');


searchField = document.querySelector('#searchField');

if (searchField != null) {
    searchField.addEventListener('keyup', (e) => {

        const searchValue = e.target.value;

        if (searchValue.trim().length > 0) {

            paginationContainer.style.display = 'none';
            

            
            fetch('/search_material/', {
                body: JSON.stringify({ searchText: searchValue }),
                method: 'POST',
            })
                .then((res) => res.json())
                .then((data) => {


                    tbody.innerHTML = "";


                    appTable.style.display = 'none';

                    tableOutput.style.display = 'block';
                    
                    if (data.length === 0) {
                        tableOutput.innerHTML = "No results found";
                    }
                    else {

                        data.forEach(item => {
                            


                            tbody.innerHTML += `
                            <tr>
                                <td>${item.material_id}</td>
                                <td>${item.material_name}</td>
                                <td>${item.material_quantity}</td>
                                <td>${item.material_description}</td>
                                <td>
                                    <a href="{% url 'edit_materials' material.material_id %}" class="btn btn-secondary">Edit</a>
                                    <a href="{% url 'delete_materials' material.material_id %}" class="btn btn-danger">Delete</a>
                                </td>


                            
                            `
                        });

                        

                    }
            
                });

        }
        else {
            appTable.style.display = 'block';
            paginationContainer.style.display = 'block';
            tableOutput.style.display = 'none';
        }

    });
}

const supplierField = document.getElementById("supp");

console.log('supplierField : ' , supplierField);

if (supplierField != null) {
    supplierField.addEventListener('change', (e) => {

        console.log('supplierField changed');

        const supplierValue = e.target.value;

        console.log('supplierValue : ' , supplierValue);

        // search for the materials with the selected supplier id

        fetch(`/get_supplier_materials/1/`, {
            body: JSON.stringify({ supplierText: supplierValue }),
            method: 'POST',
        })
            .then((res) => res.json())
            .then((data) => {

                console.log('data : ' , data);

                materials = document.getElementById("materials");

                materials.innerHTML = "";

                data.forEach(item => {
                        
                        materials.innerHTML += `
                        <option value="${item.material_id}">${item.material_name}</option>
                        `
                    }

                );

            });

    });

}


















