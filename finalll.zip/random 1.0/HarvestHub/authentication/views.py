import json
from django.http import JsonResponse
from django.shortcuts import render
from django.views import View
from django.contrib.auth.models import User
from validate_email import validate_email
from django.contrib import messages


    
class UserNameValidationView(View):
    def post(self, request):
        data = json.loads(request.body)
        username = data['username']

        if not str(username).isalnum():
            return JsonResponse({'username_error': 'Username should only contain alphanumeric characters'}, status=400)
        
        if User.objects.filter(username=username).exists():
            return JsonResponse({'username_error': 'Sorry, this username is already in use. Please try another one'}, status=409)
        
        return JsonResponse({'username_valid': True})
    
class EmailValidationView(View):
    def post(self, request):
        data = json.loads(request.body)
        email = data['email']

        if  not validate_email(email):
            return JsonResponse({'email_error': 'Email is invalid'}, status=400)
        
        if User.objects.filter(email=email).exists():
            return JsonResponse({'email_error': 'Sorry, this email is already in use. Please try another one'}, status=409)
        
        return JsonResponse({'email_valid': True})
    
class passwordValidationView(View):
    def post(self, request):
        data = json.loads(request.body)
        password = data['password']

        if len(password) < 8:
            return JsonResponse({'password_error': 'Password must be at least 8 characters long'}, status=400)
        
        return JsonResponse({'password_valid': True})
        


class RegestrationView(View):
    def get(self, request):
        return render(request, 'authentication/register.html')
    
    def post(self, request):

        
        # Get User Data
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        
        # Validation
        context = {
            'fieldValues': request.POST
        }
        
        if not User.objects.filter(username=username).exists():
            if not User.objects.filter(email=email).exists():
               
                user = User.objects.create_user(username=username, email=email)
                user.set_password(password)
                user.is_active = False
                user.save()

                messages.success(request, 'Account created successfully.')

                
                return render(request, 'authentication/register.html', context)
        
        return render(request, 'authentication/register.html', context)

        