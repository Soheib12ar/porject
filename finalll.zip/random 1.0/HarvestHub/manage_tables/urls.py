from django.urls import path
from . import views
from django.views.decorators.csrf import csrf_exempt

#------------------------
from .files import product
from .files import client
from .files import employee
from .files import center
from .files import supplier
from .files import sale
#------------------------



urlpatterns = [
    
    path("", views.index, name="manage_tables"),
    path("get_categories/", views.get_categories, name="get_categories"),
    path("export_pdf/", views.export_pdf, name="export_pdf"),








    # ---------product------------
    path("product_table/", product.product_table, name="product_table"),
    path("add_product/", product.add_product, name="add_product"),
    path("edit_product/<int:id>/", product.edit_product, name="edit_product"),
    path("delete_product/<int:id>/", product.delete_product, name="delete_product"),
    path("search_product/", csrf_exempt(product.search_product), name="search_product"),
    # -------------client----------
    path("client_table/", client.client_table, name="client_table"),
    path("add_client/", client.add_client, name="add_client"),
    path("edit_client/<int:id>/", client.edit_client, name="edit_client"),
    path("delete_client/<int:id>/", client.delete_client, name="delete_client"),
    path("search_client/", csrf_exempt(client.search_client), name="search_client"),
    #-----------employee---------------
    path("employee_table/", employee.employee_table, name="employee_table"),
    path("add_employee/", employee.add_employee, name="add_employee"),
    path("edit_employee/<int:id>/", employee.edit_employee, name="edit_employee"),
    path("delete_employee/<int:id>/", employee.delete_employee, name="delete_employee"),
    path("search_employee/", csrf_exempt(employee.search_employee), name="search_employee"),
    # -------------center----------
    path("center_table/", center.center_table, name="center_table"),
    path("add_center/", center.add_center, name="add_center"),
    path("edit_center/<int:id>/", center.edit_center, name="edit_center"),
    path("delete_center/<int:id>/", center.delete_center, name="delete_center"),
    path("search_center/", csrf_exempt(center.search_center), name="search_center"),
    # -------------supplier----------
    path("supplier_table/", supplier.supplier_table, name="supplier_table"),
    path("add_supplier/", supplier.add_supplier, name="add_supplier"),
    path("edit_supplier/<int:id>/", supplier.edit_supplier, name="edit_supplier"),
    path("delete_supplier/<int:id>/", supplier.delete_supplier, name="delete_supplier"),
    path("search_supplier/", csrf_exempt(supplier.search_supplier), name="search_supplier"),

    #---------------sales----------------
    path("", views.index, name="manage_centers"),
    path("sale_table/", sale.sale_table, name="sale_table"),
    path("add_sale/", sale.add_sale, name="add_sale"),
    path("edit_sale/<int:id>/", sale.edit_sale, name="edit_sale"),
    path("delete_sale/<int:id>/", sale.delete_sale, name="delete_sale"),
    path("search_sale/", csrf_exempt(sale.search_sale), name="search_sale"),




]










