console.log("client.js loaded");


const searchField = document.querySelector('#searchField');

const tableOutput = document.querySelector('.table-output');
tableOutput.style.display = 'none';

const appTable = document.querySelector('.app-table');
const paginationContainer = document.querySelector('.pagination-container');

const tbody = document.querySelector('.table-body');

const noResultsDiv = document.querySelector('.no-results');
noResultsDiv.style.display = 'none';


searchField.addEventListener('keyup', (e) => {

    const searchValue = e.target.value;

    if (searchValue.trim().length > 0) {

        paginationContainer.style.display = 'none';
        

        
        fetch('/manage_tables/search_client/', {
            body: JSON.stringify({ searchText: searchValue }),
            method: 'POST',
        })
            .then((res) => res.json())
            .then((data) => {

                tbody.innerHTML = "";

                appTable.style.display = 'none';

                tableOutput.style.display = 'block';

                if (data.length === 0) {
                    noResultsDiv.style.display = 'block';
                    tableOutput.style.display = 'none';
                }
                else {
                    noResultsDiv.style.display = 'none';
                    

                    data.forEach(item => {

                        tbody.innerHTML += `
                        <tr>
                            <td>${item.client_id}</td>
                            <td>${item.client_name}</td>
                            <td>${item.client_email}</td>
                            <td>${item.client_address}</td>
                            <td>${item.client_balance}</td>

                            <td>
                                <a href="/manage_tables/update_client/${item.client_id}" class="btn btn-outline-success btn-sm">Edit</a>
                                <a href="/manage_tables/delete_client/${item.client_id}" class="btn btn-outline-danger btn-sm">Delete</a>
                            </td>

                        </tr>
                        `

                    })
                }
            }
            )
        }
        else {
            tableOutput.style.display = 'none';
            appTable.style.display = 'block';
            paginationContainer.style.display = 'block';
        }
    }
);


