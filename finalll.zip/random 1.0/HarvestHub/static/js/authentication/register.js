console.log("register.js loaded");

const usernameField = document.querySelector("#username");
const usernameFeedback = document.querySelector(".invalid-username-feedback");

const emailField = document.querySelector("#email");
const emailFeedback = document.querySelector(".invalid-email-feedback");

const showPasswordToggle = document.querySelector(".showPasswordToggle");
const passwordField = document.querySelector("#password");
const passwordFeedback = document.querySelector(".invalid-password-feedback");

const submitBtn = document.querySelector(".submit-btn");

usernameField.addEventListener("keyup", (e) => {
    

    const username = e.target.value;

    

    if (username.length > 0) {
        

        fetch("/authentication/validate-username/", {
            body: JSON.stringify({ username: username }),
            method: "POST",
        })
        .then((res) => res.json())

        .then((data) => { 
            console.log("data : ",data);
            if (data.username_error) {
                submitBtn.setAttribute("disabled", "disabled");
                usernameField.classList.add("is-invalid");
                usernameFeedback.style.display = "block";
                usernameFeedback.innerHTML = `<p>${data.username_error}</p>`;

            } else {
                submitBtn.removeAttribute("disabled");
                usernameField.classList.remove("is-invalid");
                usernameFeedback.style.display = "none";

            }
        });




    }
}
);


emailField.addEventListener("keyup", (e) => {
    const email = e.target.value;

    if (email.length > 0) {
        fetch("/authentication/validate-email/", {
            body: JSON.stringify({ email: email }),
            method: "POST",
        })
        .then((res) => res.json())
        .then((data) => {
            if (data.email_error) {
                submitBtn.setAttribute("disabled", "disabled");
                emailField.classList.add("is-invalid");
                emailFeedback.style.display = "block";
                emailFeedback.innerHTML = `<p>${data.email_error}</p>`;
            } else {
                submitBtn.removeAttribute("disabled");
                emailField.classList.remove("is-invalid");
                emailFeedback.style.display = "none";
            }
        });
    }
});

passwordField.addEventListener("keyup", (e) => {
    const password = e.target.value;

    if (password.length > 0) {
        fetch("/authentication/validate-password/", {
            body: JSON.stringify({ password: password }),
            method: "POST",
        })
        .then((res) => res.json())
        .then((data) => {
            if (data.password_error) {
                submitBtn.setAttribute("disabled", "disabled");
                passwordField.classList.add("is-invalid");
                passwordFeedback.style.display = "block";
                passwordFeedback.innerHTML = `<p>${data.password_error}</p>`;
            } else {
                submitBtn.removeAttribute("disabled");
                passwordField.classList.remove("is-invalid");
                passwordFeedback.style.display = "none";
            }
        });
    }
}
);

showPasswordToggle.addEventListener("click", (e) => {
    const passwordField = document.querySelector("#password");
    
    if (e.target.textContent === "SHOW") {
        e.target.textContent = "HIDE";
        passwordField.setAttribute("type", "text");
    } 
    else {
        e.target.textContent = "SHOW";
        passwordField.setAttribute("type", "password");
    }
}
);

















