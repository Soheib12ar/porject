import datetime
from django.shortcuts import render
from app.models import product, supplier, center, employee, client
from django.contrib import messages
from django.contrib import messages
from app.models import product, client, employee, center, supplier
from django.core.paginator import Paginator
import json
from django.http import HttpResponse, JsonResponse


from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa




# -------------------product----------------------------------#


def product_table(request):
    products = product.objects.all()
    products = products.order_by("product_id")

    pages = Paginator(products, 10)
    page_number = request.GET.get("page")

    products_obj = pages.get_page(page_number)

    context = {"products": products, "products_obj": products_obj}

    return render(request, "main/manage_tables/tables/product/product.html", context)


def add_product(request):
    if request.method == "GET":
        return render(request, "main/manage_tables/tables/product/add_product.html")

    if request.method == "POST":
        context = {"data": request.POST}

        product_name = request.POST.get("product_name")
        if not product_name:
            messages.error(request, "Product name cannot be empty")
            return render(
                request, "main/manage_tables/tables/product/add_product.html", context
            )

        product_price = request.POST.get("price")
        if not product_price:
            messages.error(request, "Product price cannot be empty")
            return render(
                request, "main/manage_tables/tables/product/add_product.html", context
            )

        product_quantity = request.POST.get("quantity")
        if not product_quantity:
            messages.error(request, "Product quantity cannot be empty")
            return render(
                request, "main/manage_tables/tables/product/add_product.html", context
            )

        product_category = request.POST.get("category")
        if not product_category:
            messages.error(request, "Product category cannot be empty")
            return render(
                request, "main/manage_tables/tables/product/add_product.html", context
            )

        product.objects.create(
            product_name=product_name,
            product_price=product_price,
            product_quantity=product_quantity,
            product_category=product_category,
        )
        messages.success(request, "Product added successfully")

        products = product.objects.all()
        products = products.order_by("product_id")
        pages = Paginator(products, 10)
        page_number = request.GET.get("page")
        products_obj = pages.get_page(page_number)
        context = {"products": products, "products_obj": products_obj}

        return render(
            request, "main/manage_tables/tables/product/product.html", context
        )


def edit_product(request, id):
    product_instance = product.objects.get(pk=id)
    context = {"id": id, "data": product_instance}

    if request.method == "GET":
        return render(
            request, "main/manage_tables/tables/product/edit_product.html", context
        )

    if request.method == "POST":
        product_name = request.POST.get("product_name")
        if not product_name:
            messages.error(request, "Product name cannot be empty")
            return render(
                request, "main/manage_tables/tables/product/edit_product.html", context
            )

        product_price = request.POST.get("price")
        if not product_price:
            messages.error(request, "Product price cannot be empty")
            return render(
                request, "main/manage_tables/tables/product/edit_product.html", context
            )

        product_quantity = request.POST.get("quantity")
        if not product_quantity:
            messages.error(request, "Product quantity cannot be empty")
            return render(
                request, "main/manage_tables/tables/product/edit_product.html", context
            )

        product_category = request.POST.get("category")
        if not product_category:
            messages.error(request, "Product category cannot be empty")
            return render(
                request, "main/manage_tables/tables/product/edit_product.html", context
            )

        product_instance.product_name = product_name
        product_instance.product_price = product_price
        product_instance.product_quantity = product_quantity
        product_instance.product_category = product_category
        product_instance.save()
        messages.success(request, "Product updated successfully")

        products = product.objects.all()
        products = products.order_by("product_id")
        pages = Paginator(products, 10)
        page_number = request.GET.get("page")
        products_obj = pages.get_page(page_number)
        context = {"products": products, "products_obj": products_obj}

        return render(
            request, "main/manage_tables/tables/product/product.html", context
        )


def delete_product(request, id):
    product_instance = product.objects.get(pk=id)
    product_instance.delete()
    messages.success(request, "Product deleted successfully")

    products = product.objects.all()
    products = products.order_by("product_id")
    pages = Paginator(products, 10)
    page_number = request.GET.get("page")
    products_obj = pages.get_page(page_number)
    context = {"products": products, "products_obj": products_obj}
    return render(request, "main/manage_tables/tables/product/product.html", context)


def search_product(request):
    if request.method == "POST":
        search_str = json.loads(request.body).get("searchText")

        products = (
            product.objects.filter(product_name__icontains=search_str)
            | product.objects.filter(product_category__icontains=search_str)
            | product.objects.filter(product_price__icontains=search_str)
            | product.objects.filter(product_quantity__icontains=search_str)
        )

        data = products.values()

        return JsonResponse(list(data), safe=False)

