console.log("products.js loaded");

const categories = document.querySelector('#categories');

function setCategories() {
    fetch('/manage_tables/get_categories/')
        .then((res) => res.json())
        .then((data) => {

            data = data['categories'];


            categories.innerHTML = "";
            // without using forEach
            for (let i = 0; i < data.length; i++) {
                categories.innerHTML += `
                    <option value="${data[i]}">${data[i]}</option>
                `
            }

        });
}

setCategories();
