from django.urls import path
from . import views
from django.views.decorators.csrf import csrf_exempt

urlpatterns = [
    path('', views.index, name='index'),
    path('stock/', views.stock, name='stock'),



    #-------------------- materials --------------------
    path('materials/', views.materials, name='materials'),
    path('buy_materials/', views.buy_materials, name='buy_materials'),
    path('edit_materials/<int:id>/', views.edit_materials, name='edit_materials'),
    path('delete_materials/<int:id>/', views.delete_materials, name='delete_materials'),
    path('sell_materials/', views.sell_materials, name='sell_materials'),
    path('search_material/', views.search_material, name='search_material'),
    path('get_suppliers/<int:id>/', csrf_exempt(views.get_suppliers), name='get_suppliers'),
    path('get_materials/<int:id>/', csrf_exempt(views.get_materials), name='get_materials'),



    #-------------------- purchases --------------------
    path('purchases_list', views.purchases_list, name='purchases_list'),

    #-------------------- transfers --------------------
    path('transfers_list', views.transfers_list, name='transfers_list'),
    path('transfers_list/<int:id>', views.transfers_list, name='transfers_list_c'),
    path('add_transfer/', views.add_transfer, name='add_transfer'),

    #-------------------- stock --------------------
    path('stock_status/', views.stock_status, name='stock_status'),
]