console.log("search_employee.js loaded");

const searchField = document.querySelector('#searchField');

const tableOutput = document.querySelector('.table-output');
tableOutput.style.display = 'none';

const appTable = document.querySelector('.app-table');
const paginationContainer = document.querySelector('.pagination-container');

const tbody = document.querySelector('.table-body');

const noResultsDiv = document.querySelector('.no-results');
noResultsDiv.style.display = 'none';

searchField.addEventListener('keyup', (e) => {

    const searchValue = e.target.value;

    if (searchValue.trim().length > 0) {

        paginationContainer.style.display = 'none';

        fetch('/manage_tables/search_employee/', {
            body: JSON.stringify({ searchText: searchValue }),
            method: 'POST',
        })
            .then((res) => res.json())
            .then((data) => {

                tbody.innerHTML = "";

                appTable.style.display = 'none';

                tableOutput.style.display = 'block';

                if (data.length === 0) {
                    noResultsDiv.style.display = 'block';
                    tableOutput.style.display = 'none';
                }
                else {
                    noResultsDiv.style.display = 'none';

                    data.forEach(employee => {
                        tbody.innerHTML += `
                        <tr>
                            <td>${employee.employee_id}</td>
                            <td>${employee.employee_name}</td>
                            <td>${employee.employee_salary}</td>
                            <td>${employee.employee_position}</td>
                            <td>${employee.employee_department}</td>
                            <td>
                                <a href="/manage_tables/edit_employee/${employee.employee_id}" class="btn btn-secondary">Edit</a>
                                <a href="/manage_tables/delete_employee/${employee.employee_id}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        `;
                    });
                }
            });

    }
    else {
        appTable.style.display = 'block';
        paginationContainer.style.display = 'block';
        tableOutput.style.display = 'none';
        noResultsDiv.style.display = 'none';
    }

});
