console.log('sell_materials.js loaded');

let quantity
let price

const quantityInput = document.getElementById('quantity')
const priceInput = document.getElementById('priceBox')

const totalPrice = document.getElementById('total')

function calculateTotal() {
    totalPrice.innerHTML = quantity * price
}


quantityInput.addEventListener('keyup', (e) => {
    quantity = e.target.value
    if (price) {
        calculateTotal()
    }
}
)

priceInput.addEventListener('keyup', (e) => {
    price = e.target.value
    if (quantity) {
        calculateTotal()
    }
}
)

