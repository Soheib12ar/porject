console.log("analysis.js loaded");


const topSuppliersTable = document.getElementById("top-suppliers-table");

topSupliers = {}

function getTopSuppliers() {

    url = "/analysis/get_top_suppliers/"

    fetch(url)
        .then(response => response.json())
        .then(data => {
            topSupliers = data;
            populateTopSuppliersTable();
        })
        .catch(error => console.log(error))
}

function populateTopSuppliersTable() {
    for (let i = 0; i < topSupliers.length; i++) {
        

        topSuppliersTable.innerHTML += `
            <tr>
                    <th scope="row">${i+1}</th>
                    <th scope="row">${topSupliers[i][0]}</th>
                    <td>${topSupliers[i][1]}</td>
                  </tr>
        `



        
    }
}

getTopSuppliers();

















