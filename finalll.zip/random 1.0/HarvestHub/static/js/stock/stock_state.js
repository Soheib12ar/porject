console.log("stock_state.js loaded");

