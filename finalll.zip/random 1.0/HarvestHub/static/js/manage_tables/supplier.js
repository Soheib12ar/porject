console.log("supplier.js loaded");


const searchField = document.querySelector('#searchField');

const tableOutput = document.querySelector('.table-output');
tableOutput.style.display = 'none';

const appTable = document.querySelector('.app-table');
const paginationContainer = document.querySelector('.pagination-container');

const tbody = document.querySelector('.table-body');

const noResultsDiv = document.querySelector('.no-results');
noResultsDiv.style.display = 'none';


searchField.addEventListener('keyup', (e) => {
    
        const searchValue = e.target.value;

    
        if (searchValue.trim().length > 0) {
    
            paginationContainer.style.display = 'none';

            fetch('/manage_tables/search_supplier/', {
                body: JSON.stringify({ searchText: searchValue }),
                method: 'POST',
            })
                .then((res) => res.json())
                .then((data) => {
    
    
                    tbody.innerHTML = "";
    
    
                    appTable.style.display = 'none';
    
                    tableOutput.style.display = 'block';
                    
                    if (data.length === 0) {
                        noResultsDiv.style.display = 'block';
                        tableOutput.style.display = 'none';
                    }
                    else {
                        noResultsDiv.style.display = 'none';
                        
    
                        data.forEach(item => {
    
    
                            tbody.innerHTML += `
                            <tr>
                                <td>${item.supplier_id}</td>
                                <td>${item.supplier_name}</td>
                                <td>${item.supplier_address}</td>
                                <td>${item.supplier_contact}</td>
                                <td>${item.supplier_email}</td>
                                <td>${item.supplier_description}</td>
                                <td>
                                    <a href="/manage_tables/edit_supplier/${item.supplier_id}" class="btn btn-outline-success btn-sm">Edit</a>
                                </td>
                                <td>
                                    <a href="/manage_tables/delete_supplier/${item.supplier_id}" class="btn btn-outline-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                        `
                        })
                    }
    
                });

        }
        else {
            tableOutput.style.display = 'none';
            appTable.style.display = 'block';
            paginationContainer.style.display = 'block';
        }


    }
);











