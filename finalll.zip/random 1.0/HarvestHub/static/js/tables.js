console.log("tables.js loaded");

const tableSelect = document.getElementById("table-select");
const tableBody = document.querySelector("#data-table tbody");

// Add event listener to the select element
tableSelect.addEventListener("change", function () {

    console.log("tableSelect event listener fired");
    // Get the value of the selected option
    const selectedOption = this.options[tableSelect.selectedIndex];
    const selectedTable = selectedOption.value;

    console.log("selectedTable : ", selectedTable);

    // sends a GET request to the server to show the table

    fetch(`/table/ `)

        .then(response => response.json())
        


}
);


