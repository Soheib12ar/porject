import datetime
from django.shortcuts import render
from app.models import product, supplier, center, employee, client
from django.contrib import messages
from django.contrib import messages
from app.models import product, client, employee, center, supplier
from django.core.paginator import Paginator
import json
from django.http import HttpResponse, JsonResponse


from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa












# ------------supplier------------#
def supplier_table(request):
    suppliers = supplier.objects.all()
    suppliers = suppliers.order_by("supplier_id")

    pages = Paginator(suppliers, 10)
    page_number = request.GET.get("page")

    suppliers_obj = pages.get_page(page_number)

    context = {"suppliers": suppliers, "suppliers_obj": suppliers_obj}

    return render(request, "main/manage_tables/tables/supplier/supplier.html", context)


def add_supplier(request):
    if request.method == "GET":
        return render(request, "main/manage_tables/tables/supplier/add_supplier.html")

    if request.method == "POST":
        context = {"data": request.POST}

        supplier_name = request.POST.get("supplier_name")
        if not supplier_name:
            messages.error(request, "Client name cannot be empty")
            return render(
                request, "main/manage_tables/tables/supplier/add_supplier.html", context
            )

        supplier_address = request.POST.get("address")
        if not supplier_address:
            messages.error(request, "Client address cannot be empty")
            return render(
                request, "main/manage_tables/tables/supplier/add_supplier.html", context
            )

        supplier_phone = request.POST.get("phone")
        if not supplier_phone:
            messages.error(request, "Client phone  cannot be empty")
            return render(
                request, "main/manage_tables/tables/supplier/add_supplier.html", context
            )

        supplier_email = request.POST.get("email")
        if not supplier_email:
            messages.error(request, "Client email cannot be empty")
            return render(
                request, "main/manage_tables/tables/supplier/add_supplier.html", context
            )

        supplier.objects.create(
            supplier_name=supplier_name,
            supplier_address=supplier_address,
            supplier_phone=supplier_phone,
            supplier_email=supplier_email,
        )
        messages.success(request, "Client added successfully")

        suppliers = supplier.objects.all()
        suppliers = suppliers.order_by("supplier_id")
        pages = Paginator(suppliers, 10)
        page_number = request.GET.get("page")
        suppliers_obj = pages.get_page(page_number)
        context = {"suppliers": suppliers, "suppliers_obj": suppliers_obj}

        return render(
            request, "main/manage_tables/tables/supplier/supplier.html", context
        )


def edit_supplier(request, id):
    supplier_instance = supplier.objects.get(pk=id)
    context = {"id": id, "data": supplier_instance}

    if request.method == "GET":
        return render(
            request, "main/manage_tables/tables/supplier/edit_supplier.html", context
        )

    if request.method == "POST":
        supplier_name = request.POST.get("supplier_name")
        if not supplier_name:
            messages.error(request, "Client name cannot be empty")
            return render(
                request,
                "main/manage_tables/tables/supplier/edit_supplier.html",
                context,
            )

        supplier_address = request.POST.get("address")
        if not supplier_address:
            messages.error(request, "Client address cannot be empty")
            return render(
                request,
                "main/manage_tables/tables/supplier/edit_supplier.html",
                context,
            )

        supplier_phone = request.POST.get("phone")
        if not supplier_phone:
            messages.error(request, "Client phone cannot be empty")
            return render(
                request,
                "main/manage_tables/tables/supplier/edit_supplier.html",
                context,
            )

        supplier_email = request.POST.get("email")
        if not supplier_email:
            messages.error(request, "Client email cannot be empty")
            return render(
                request,
                "main/manage_tables/tables/supplier/edit_supplier.html",
                context,
            )

        supplier_instance.supplier_name = supplier_name
        supplier_instance.supplier_address = supplier_address
        supplier_instance.supplier_phone = supplier_phone
        supplier_instance.supplier_email = supplier_email
        supplier_instance.save()
        messages.success(request, "Client updated successfully")

        suppliers = supplier.objects.all()
        suppliers = suppliers.order_by("supplier_id")
        pages = Paginator(suppliers, 10)
        page_number = request.GET.get("page")
        suppliers_obj = pages.get_page(page_number)
        context = {"suppliers": suppliers, "suppliers_obj": suppliers_obj}

        return render(
            request, "main/manage_tables/tables/supplier/supplier.html", context
        )


def delete_supplier(request, id):
    supplier_instance = supplier.objects.get(pk=id)
    supplier_instance.delete()
    messages.success(request, "Product deleted successfully")

    suppliers = supplier.objects.all()
    suppliers = suppliers.order_by("supplier_id")
    pages = Paginator(suppliers, 10)
    page_number = request.GET.get("page")
    suppliers_obj = pages.get_page(page_number)
    context = {"suppliers": suppliers, "suppliers_obj": suppliers_obj}
    return render(request, "main/manage_tables/tables/supplier/supplier.html", context)


def search_supplier(request):
    if request.method == "POST":
        search_str = json.loads(request.body).get("searchText")

        suppliers = (
            supplier.objects.filter(supplier_name__icontains=search_str)
            | supplier.objects.filter(supplier_address__icontains=search_str)
            | supplier.objects.filter(supplier_phone__icontains=search_str)
            | supplier.objects.filter(supplier_email__icontains=search_str)
        )

        data = suppliers.values()

        return JsonResponse(list(data), safe=False)
    

