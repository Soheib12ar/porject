from django.apps import AppConfig


class ManageCentersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'manage_centers'
