from django.urls import path
from . import views
from django.views.decorators.csrf import csrf_exempt

urlpatterns = [
    path('', views.index, name='analysis'),
    path('get_purchases_per_month/<int:year>', csrf_exempt(views.get_purchases_per_month), name='get_purchases_per_month'),
    path('get_center_sales_stats/<int:center>', csrf_exempt(views.get_center_sales_stats), name='get_center_sales_stats'),
    path('get_year_sales_stats/<int:year>', csrf_exempt(views.get_year_sales_stats), name='get_year_sales_stats'),
    path('get_top_suppliers/', csrf_exempt(views.get_top_suppliers), name='get_top_suppliers'),
    

]