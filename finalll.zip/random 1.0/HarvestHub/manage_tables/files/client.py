import datetime
from django.shortcuts import render
from app.models import product, supplier, center, employee, client
from django.contrib import messages
from django.contrib import messages
from app.models import product, client, employee, center, supplier
from django.core.paginator import Paginator
import json
from django.http import HttpResponse, JsonResponse


from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa


# ------------client------------#
def client_table(request):
    clients = client.objects.all()
    clients = clients.order_by("client_id")

    pages = Paginator(clients, 10)
    page_number = request.GET.get("page")

    clients_obj = pages.get_page(page_number)

    context = {"clients": clients, "clients_obj": clients_obj}

    return render(request, "main/manage_tables/tables/client/client.html", context)


def add_client(request):
    if request.method == "GET":
        return render(request, "main/manage_tables/tables/client/add_client.html")

    if request.method == "POST":
        context = {"data": request.POST}

        client_name = request.POST.get("client_name")
        if not client_name:
            messages.error(request, "Client name cannot be empty")
            return render(
                request, "main/manage_tables/tables/client/add_client.html", context
            )

        client_address = request.POST.get("address")
        if not client_address:
            messages.error(request, "Client address cannot be empty")
            return render(
                request, "main/manage_tables/tables/client/add_client.html", context
            )

        

        client.objects.create(
            client_name=client_name,
            client_address=client_address,
            client_balance=0,
        )
        messages.success(request, "Client added successfully")

        clients = client.objects.all()
        clients = clients.order_by("client_id")
        pages = Paginator(clients, 10)
        page_number = request.GET.get("page")
        clients_obj = pages.get_page(page_number)
        context = {"clients": clients, "clients_obj": clients_obj}

        return render(request, "main/manage_tables/tables/client/client.html", context)


def edit_client(request, id):
    client_instance = client.objects.get(pk=id)
    context = {"id": id, "data": client_instance}

    if request.method == "GET":
        return render(
            request, "main/manage_tables/tables/client/edit_client.html", context
        )

    if request.method == "POST":
        client_name = request.POST.get("client_name")
        if not client_name:
            messages.error(request, "Client name cannot be empty")
            return render(
                request, "main/manage_tables/tables/client/edit_client.html", context
            )

        client_address = request.POST.get("address")
        if not client_address:
            messages.error(request, "Client address cannot be empty")
            return render(
                request, "main/manage_tables/tables/client/edit_client.html", context
            )

        client_balance = request.POST.get("balance")
        if not client_balance:
            messages.error(request, "Client balance cannot be empty")
            return render(
                request, "main/manage_tables/tables/client/edit_client.html", context
            )

        client_instance.client_name = client_name
        client_instance.client_address = client_address
        client_instance.client_balance = client_balance
        client_instance.save()
        messages.success(request, "Client updated successfully")

        clients = client.objects.all()
        clients = clients.order_by("client_id")
        pages = Paginator(clients, 10)
        page_number = request.GET.get("page")
        clients_obj = pages.get_page(page_number)
        context = {"clients": clients, "clients_obj": clients_obj}

        return render(request, "main/manage_tables/tables/client/client.html", context)


def delete_client(request, id):
    client_instance = client.objects.get(pk=id)
    client_instance.delete()
    messages.success(request, "Product deleted successfully")

    clients = client.objects.all()
    clients = clients.order_by("client_id")
    pages = Paginator(clients, 10)
    page_number = request.GET.get("page")
    clients_obj = pages.get_page(page_number)
    context = {"clients": clients, "clients_obj": clients_obj}
    return render(request, "main/manage_tables/tables/client/client.html", context)


def search_client(request):
    if request.method == "POST":
        search_str = json.loads(request.body).get("searchText")

        clients = (
            client.objects.filter(client_name__icontains=search_str)
            | client.objects.filter(client_address__icontains=search_str)
            | client.objects.filter(client_phone__icontains=search_str)
            | client.objects.filter(client_email__icontains=search_str)
        )

        data = clients.values()

        return JsonResponse(list(data), safe=False)

