from .views import RegestrationView, UserNameValidationView , EmailValidationView , passwordValidationView
from django.urls import path
from django.views.decorators.csrf import csrf_exempt


urlpatterns = [
    path('register/', RegestrationView.as_view() , name='register'),
    path('validate-username/', csrf_exempt(UserNameValidationView.as_view()), name='validate-username'),
    path('validate-email/', csrf_exempt(EmailValidationView.as_view()), name='validate-email'),
    path('validate-password/', csrf_exempt(passwordValidationView.as_view()), name='validate-password'),
]