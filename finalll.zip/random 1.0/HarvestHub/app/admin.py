from django.contrib import admin
from .models import *


admin.site.register(material)
admin.site.register(supplier)
admin.site.register(mat_supp)
admin.site.register(material_purchase)
admin.site.register(center)
admin.site.register(material_transfer)
admin.site.register(client)
admin.site.register(material_sale)
admin.site.register(sale)

admin.site.register(product)

admin.site.register(employee)






