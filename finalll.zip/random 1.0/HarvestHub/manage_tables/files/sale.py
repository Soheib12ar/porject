import datetime
from django.shortcuts import render
from app.models import sale, center, client, product
from django.contrib import messages
from django.contrib import messages
from app.models import sale, client, center, product
from django.core.paginator import Paginator
import json
from django.http import HttpResponse, JsonResponse


from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa




# -------------------sale----------------------------------#


def sale_table(request):
    sales = sale.objects.all()
    sales = sales.order_by("sale_id")

    pages = Paginator(sales, 10)
    page_number = request.GET.get("page")

    sales_obj = pages.get_page(page_number)

    context = {"sales": sales, "sales_obj": sales_obj}

    return render(request, "main/manage_tables/tables/sale/sale.html", context)




def add_sale(request):
    if request.method == "GET":
        return render(request, "main/manage_tables/tables/sale/add_sale.html")

    if request.method == "POST":
        context = {"data": request.POST}

        sale_client = request.POST.get("sale_client")
        if not sale_client:
            messages.error(request, "sale client cannot be empty")
            return render(
                request, "main/manage_tables/tables/sale/add_sale.html", context
            )


        date = request.POST.get("date")
        if not date:
            messages.error(request, "date cannot be empty")
            return render(
                request, "main/manage_tables/tables/sale/add_sale.html", context
            )

        center = request.POST.get("center")
        if not center:
            messages.error(request, "center cannot be empty")
            return render(
                request, "main/manage_tables/tables/sale/add_sale.html", context
            )
        
        amount = request.POST.get("amount")
        if not amount:
            messages.error(request, "amount cannot be empty")
            return render(
                request, "main/manage_tables/tables/sale/add_sale.html", context
            )


        sale.objects.create(
            sale_client=sale_client,
            product=product,
            date=date,
            center=center,
            amount = amount,
        )
        messages.success(request, "sale added successfully")

        sales = sale.objects.all()
        sales = sales.order_by("sale_id")
        pages = Paginator(sales, 10)
        page_number = request.GET.get("page")
        sales_obj = pages.get_page(page_number)
        context = {"sales": sales, "sales_obj": sales_obj}

        return render(
            request, "main/manage_tables/tables/sale/sale.html", context
        )


def edit_sale(request, id):
    sale_instance = sale.objects.get(pk=id)
    context = {"id": id, "data": sale_instance}

    if request.method == "GET":
        return render(
            request, "main/manage_tables/tables/sale/edit_sale.html", context
        )

    if request.method == "POST":
        sale_client = request.POST.get("sale_client")
        if not sale_client:
            messages.error(request, "sale client cannot be empty")
            return render(
                request, "main/manage_tables/tables/sale/edit_sale.html", context
            )

        product = request.POST.get("prodcut")
        if not product:
            messages.error(request, "sale price cannot be empty")
            return render(
                request, "main/manage_tables/tables/sale/edit_sale.html", context
            )

        date = request.POST.get("date")
        if not date:
            messages.error(request, "date cannot be empty")
            return render(
                request, "main/manage_tables/tables/sale/edit_sale.html", context
            )

        center = request.POST.get("center")
        if not center:
            messages.error(request, "center cannot be empty")
            return render(
                request, "main/manage_tables/tables/sale/edit_sale.html", context
            )
        amount = request.POST.get("amount")
        if not amount:
            messages.error(request, "amount cannot be empty")
            return render(
                request, "main/manage_tables/tables/sale/add_sale.html", context
            )

        sale_instance.sale_client = sale_client
        sale_instance.sale_product = product
        sale_instance.sale_date = date
        sale_instance.sale_center = center
        sale_instance.sale_amount = amount
        sale_instance.save()
        messages.success(request, "sale updated successfully")

        sales = sale.objects.all()
        sales = sales.order_by("sale_id")
        pages = Paginator(sales, 10)
        page_number = request.GET.get("page")
        sales_obj = pages.get_page(page_number)
        context = {"sales": sales, "sales_obj": sales_obj}

        return render(
            request, "main/manage_tables/tables/sale/sale.html", context
        )


def delete_sale(request, id):
    sale_instance = sale.objects.get(pk=id)
    sale_instance.delete()
    messages.success(request, "sale deleted successfully")

    sales = sale.objects.all()
    sales = sales.order_by("sale_id")
    pages = Paginator(sales, 10)
    page_number = request.GET.get("page")
    sales_obj = pages.get_page(page_number)
    context = {"sales": sales, "sales_obj": sales_obj}
    return render(request, "main/manage_tables/tables/sale/sale.html", context)


def search_sale(request):
    if request.method == "POST":
        search_str = json.loads(request.body).get("searchText")

        sales = (
            sale.objects.filter(sale_client__icontains=search_str)
            | sale.objects.filter(sale_center__icontains=search_str)
            | sale.objects.filter(sale_product__icontains=search_str)
            | sale.objects.filter(sale_date__icontains=search_str)
            | sale.objects.filter(sale_amount__icontains=search_str)

        )

        data = sales.values()

        return JsonResponse(list(data), safe=False)

