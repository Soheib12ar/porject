import datetime
from django.shortcuts import render
from app.models import product, supplier, center, employee, client
from django.contrib import messages
from django.contrib import messages
from app.models import product, client, employee, center, supplier
from django.core.paginator import Paginator
import json
from django.http import HttpResponse, JsonResponse


from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa


def index(request):
    return render(request, "main/manage_tables/index.html")




def get_categories(request):
    if request.method == "GET":
        products = product.objects.all()
        categories = []

        #get the categories available in the database
        for p in products:
            if p.product_category not in categories:
                categories.append(p.product_category)

    #to access the dictionary in javascript, we need to convert it to json
        data = {"categories": categories}
                
            


    return JsonResponse(data, safe=False)



def export_pdf(request):

    data = {}
    
    template = get_template('main/manage_tables/tables/client/client_pdf.html')

    clients = client.objects.all()
    
    for c in clients:
        data[c.client_id] = {
            "client_name": c.client_name,
            "client_address": c.client_address,
            "client_balance": c.client_balance,
        }

    print(data)


    html = template.render({"clients": clients})
    pdf = pisa.pisaDocument(BytesIO(html.encode("UTF-8")), request=request)

    pdf 


    
