import datetime
from django.shortcuts import render
from app.models import product, supplier, center, employee, client
from django.contrib import messages
from django.contrib import messages
from app.models import product, client, employee, center, supplier
from django.core.paginator import Paginator
import json
from django.http import HttpResponse, JsonResponse


from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa










# ------------center------------#
def center_table(request):
    centers = center.objects.all()
    centers = centers.order_by("center_id")

    pages = Paginator(centers, 10)
    page_number = request.GET.get("page")

    centers_obj = pages.get_page(page_number)

    context = {"centers": centers, "centers_obj": centers_obj}

    return render(request, "main/manage_tables/tables/center/center.html", context)


def add_center(request):
    if request.method == "GET":
        return render(request, "main/manage_tables/tables/center/add_center.html")

    if request.method == "POST":
        context = {"data": request.POST}

        center_name = request.POST.get("center_name")
        if not center_name:
            messages.error(request, "Client name cannot be empty")
            return render(
                request, "main/manage_tables/tables/center/add_center.html", context
            )

        center_address = request.POST.get("address")
        if not center_address:
            messages.error(request, "Client address cannot be empty")
            return render(
                request, "main/manage_tables/tables/center/add_center.html", context
            )

        center_phone = request.POST.get("phone")
        if not center_phone:
            messages.error(request, "Client phone  cannot be empty")
            return render(
                request, "main/manage_tables/tables/center/add_center.html", context
            )

        center_email = request.POST.get("email")
        if not center_email:
            messages.error(request, "Client email cannot be empty")
            return render(
                request, "main/manage_tables/tables/center/add_center.html", context
            )

        center.objects.create(
            center_name=center_name,
            center_address=center_address,
            center_phone=center_phone,
            center_email=center_email,
        )
        messages.success(request, "Client added successfully")

        centers = center.objects.all()
        centers = centers.order_by("center_id")
        pages = Paginator(centers, 10)
        page_number = request.GET.get("page")
        centers_obj = pages.get_page(page_number)
        context = {"centers": centers, "centers_obj": centers_obj}

        return render(request, "main/manage_tables/tables/center/center.html", context)


def edit_center(request, id):
    center_instance = center.objects.get(pk=id)
    context = {"id": id, "data": center_instance}

    if request.method == "GET":
        return render(
            request, "main/manage_tables/tables/center/edit_center.html", context
        )

    if request.method == "POST":
        center_name = request.POST.get("center_name")
        if not center_name:
            messages.error(request, "Client name cannot be empty")
            return render(
                request, "main/manage_tables/tables/center/edit_center.html", context
            )

        center_address = request.POST.get("address")
        if not center_address:
            messages.error(request, "Client address cannot be empty")
            return render(
                request, "main/manage_tables/tables/center/edit_center.html", context
            )

        center_phone = request.POST.get("phone")
        if not center_phone:
            messages.error(request, "Client phone cannot be empty")
            return render(
                request, "main/manage_tables/tables/center/edit_center.html", context
            )

        center_email = request.POST.get("email")
        if not center_email:
            messages.error(request, "Client email cannot be empty")
            return render(
                request, "main/manage_tables/tables/center/edit_center.html", context
            )

        center_instance.center_name = center_name
        center_instance.center_address = center_address
        center_instance.center_phone = center_phone
        center_instance.center_email = center_email
        center_instance.save()
        messages.success(request, "Client updated successfully")

        centers = center.objects.all()
        centers = centers.order_by("center_id")
        pages = Paginator(centers, 10)
        page_number = request.GET.get("page")
        centers_obj = pages.get_page(page_number)
        context = {"centers": centers, "centers_obj": centers_obj}

        return render(request, "main/manage_tables/tables/center/center.html", context)


def delete_center(request, id):
    center_instance = center.objects.get(pk=id)
    center_instance.delete()
    messages.success(request, "Product deleted successfully")

    centers = center.objects.all()
    centers = centers.order_by("center_id")
    pages = Paginator(centers, 10)
    page_number = request.GET.get("page")
    centers_obj = pages.get_page(page_number)
    context = {"centers": centers, "centers_obj": centers_obj}
    return render(request, "main/manage_tables/tables/center/center.html", context)


def search_center(request):
    if request.method == "POST":
        search_str = json.loads(request.body).get("searchText")

        centers = (
            center.objects.filter(center_name__icontains=search_str)
            | center.objects.filter(center_designation__icontains=search_str)
        )

        data = centers.values()

        return JsonResponse(list(data), safe=False)

